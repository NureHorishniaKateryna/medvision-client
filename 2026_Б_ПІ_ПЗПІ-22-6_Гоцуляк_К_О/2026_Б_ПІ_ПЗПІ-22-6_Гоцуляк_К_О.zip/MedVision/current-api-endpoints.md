# Current API Endpoints

Production base URL:

- `https://api.medvision-nure.org`

Local Docker base URL:

- `http://localhost:8081`

General rules:

- API base path: `/api`
- Auth header for protected endpoints: `Authorization: Bearer <jwt>`
- Public endpoints: registration and login
- Error format for new/hardened API: `ErrorResponse`
- Hospital-scoped endpoints always include `hospitalId` in the path and validate user membership/access on the backend

## 1. Legacy Endpoints

These endpoints existed before the practice/diploma-scale expansion or preserve the original course-work flow. They remain useful for backward compatibility and for frontend screens that still use the old analysis-centric model.

### Auth And Profile

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/auth/register/patient` | Public | Register patient and return JWT |
| `POST` | `/api/auth/register/admin` | Public | Register system admin and return JWT |
| `POST` | `/api/auth/login` | Public | Login user and return JWT |
| `GET` | `/api/auth/profile` | Authenticated | Get current user profile |
| `PUT` | `/api/auth/edit/doctor` | Authenticated doctor | Update current doctor profile |
| `PUT` | `/api/auth/edit/patient` | Authenticated patient | Update current patient profile |

### User Administration

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/users` | `ADMIN` | Get all users |
| `GET` | `/api/users/{id}` | `ADMIN` | Get user by id |
| `DELETE` | `/api/users/{id}` | `ADMIN` | Delete user |
| `PATCH` | `/api/users/{id}/role` | `ADMIN` | Change user global role |
| `POST` | `/api/users/register-doctor` | `ADMIN` | Register doctor and send generated credentials by email |

### Doctor Analysis Flow

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/doctor/images/analyze` | Doctor/Admin by security config | Upload image and run analysis in legacy flow |
| `GET` | `/api/doctor/analysis/{id}` | Doctor/Admin by security config | Get analysis details |
| `GET` | `/api/doctor/heatmap/{id}` | Doctor/Admin by security config | Get analysis heatmap as PNG |
| `POST` | `/api/doctor/analysis/{id}/diagnosis` | Doctor/Admin by security config | Update diagnosis text for analysis |
| `GET` | `/api/doctor/patients` | Doctor/Admin by security config | Get all patients |
| `GET` | `/api/doctor/patients/{id}` | Doctor/Admin by security config | Get patient by id |
| `POST` | `/api/doctor/analyses/{analysesId}/notes` | Doctor/Admin by security config | Add note to analysis |

Request details for legacy image analysis:

- `POST /api/doctor/images/analyze`
- `multipart/form-data`
- fields: `file`, `patientId`, `doctorId`
- response: plain text, for example `Analysis saved. ID: 123`
- compatibility note: current backend keeps this endpoint but internally can attach the analysis to a legacy treatment/job flow.

### Patient Analysis Flow

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/patient/analyses` | Patient | Get current patient's analyses |
| `GET` | `/api/patient/analyses/{id}` | Patient | Get current patient's analysis by id |
| `GET` | `/api/patient/analyses/unviewed` | Patient | Get unviewed analyses |
| `POST` | `/api/patient/analyses/{id}/mark-viewed` | Patient | Mark analysis as viewed |
| `GET` | `/api/patient/heatmap/{id}` | Patient | Get heatmap as PNG |
| `GET` | `/api/patient/analyses/pdf/{id}` | Patient | Download analysis PDF report |

### Analysis Management

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/analysis` | `DOCTOR`, `ADMIN` | Get all analyses |
| `GET` | `/api/analysis/{id}` | `DOCTOR`, `ADMIN` | Get analysis by id |
| `GET` | `/api/analysis/doctor/{doctorId}` | `DOCTOR`, `ADMIN` | Get analyses by doctor |
| `GET` | `/api/analysis/patient/{patientId}` | `DOCTOR`, `ADMIN` | Get analyses by patient |
| `PATCH` | `/api/analysis/{id}/status` | `DOCTOR`, `ADMIN` | Update analysis status |
| `GET` | `/api/analysis/{id}/status` | `DOCTOR`, `ADMIN` | Get analysis status |
| `GET` | `/api/analysis/compare?fromId={fromId}&toId={toId}` | `DOCTOR`, `ADMIN`, `PATIENT` | Compare two analyses |
| `GET` | `/api/analysis/compare/pdf?fromId={fromId}&toId={toId}` | `DOCTOR`, `ADMIN`, `PATIENT` | Download comparison PDF |
| `DELETE` | `/api/analysis/{id}` | `DOCTOR`, `ADMIN` | Delete analysis |

### Analysis Notes

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/analysis-note/by-analysis/{analysisId}` | `DOCTOR`, `ADMIN` | Get notes by analysis |
| `GET` | `/api/analysis-note/by-analysis/{analysisId}/bounding-boxes` | `DOCTOR`, `ADMIN` | Get note bounding boxes by analysis |
| `GET` | `/api/analysis-note/{id}` | `DOCTOR`, `ADMIN` | Get note by id |
| `PUT` | `/api/analysis-note/{id}` | `DOCTOR`, `ADMIN` | Update note |
| `DELETE` | `/api/analysis-note/{id}` | `ADMIN` | Delete note |

### Diagnosis History

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/diagnosis/{id}` | Authenticated by security config | Get diagnosis history item |
| `GET` | `/api/diagnosis/analysis/{analysisId}` | Authenticated by security config | Get diagnosis history for analysis |
| `POST` | `/api/diagnosis` | Authenticated by security config | Create diagnosis history item |

### Dataset And Legacy SVM Training

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/dataset/build` | Authenticated by security config | Build dataset using backend dataset service |
| `POST` | `/api/svm/train?datasetPath={datasetPath}` | Authenticated by security config | Train full-image and patch SVM models from directory |

Production limitation:

- `MEDVISION_SVM_PRELOAD_ENABLED=false` is currently set on the server, so SVM-heavy flows should be separately tested before demo usage.

## 2. New Endpoints Implemented During Practice Expansion

These endpoints implement the expanded product/scientific scope: hospital context, treatment lifecycle, analysis jobs, SVM model registry/research support, treatment dynamics, conclusions, and treatment reports.

### Hospital Administration

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/admin/hospitals` | `ADMIN` | Create hospital |
| `GET` | `/api/admin/hospitals` | `ADMIN` | Get all hospitals |
| `PATCH` | `/api/admin/hospitals/{hospitalId}` | `ADMIN` | Update hospital |

Main request DTOs:

- `HospitalCreateRequest`
- `HospitalUpdateRequest`

Main response DTO:

- `HospitalResponse`

### Hospital Context And Memberships

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/hospitals/my` | Authenticated | Get hospitals available to current user |
| `POST` | `/api/hospitals/{hospitalId}/select` | Authenticated active member | Select active hospital context |
| `POST` | `/api/hospitals/{hospitalId}/memberships` | Authenticated hospital admin/allowed role | Add user membership to hospital |
| `GET` | `/api/hospitals/{hospitalId}/memberships` | Authenticated hospital member with access | Get hospital memberships |
| `GET` | `/api/hospitals/{hospitalId}/memberships?role={role}` | Authenticated hospital member with access | Get hospital memberships filtered by role |
| `PATCH` | `/api/hospitals/{hospitalId}/memberships/{membershipId}/status` | Authenticated hospital admin/allowed role | Update hospital membership status |

Supported membership role filter:

- `role`: `DOCTOR`, `PATIENT`, `HOSPITAL_ADMIN` depending on current enum values

Main request DTOs:

- `HospitalMembershipCreateRequest`
- `HospitalMembershipStatusRequest`

Main response DTOs:

- `MyHospitalResponse`
- `ActiveHospitalResponse`
- `HospitalMembershipResponse`

### Treatment Lifecycle

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/hospitals/{hospitalId}/treatments` | Authenticated hospital doctor/admin | Create treatment for patient |
| `GET` | `/api/hospitals/{hospitalId}/treatments` | Authenticated hospital member | Get treatments in hospital |
| `GET` | `/api/hospitals/{hospitalId}/treatments?patientId={patientId}` | Authenticated hospital member | Get treatments filtered by patient |
| `GET` | `/api/hospitals/{hospitalId}/treatments?doctorId={doctorId}` | Authenticated hospital member | Get treatments filtered by doctor |
| `GET` | `/api/hospitals/{hospitalId}/treatments?status={status}` | Authenticated hospital member | Get treatments filtered by status |
| `GET` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}` | Authenticated hospital member | Get treatment timeline |
| `PATCH` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/close` | Authenticated hospital doctor/admin | Close treatment |

Supported treatment statuses:

- `ACTIVE`
- `CLOSED`
- other statuses if added to `TreatmentStatus`

Main request DTOs:

- `TreatmentCreateRequest`
- `TreatmentCloseRequest`

Main response DTOs:

- `TreatmentResponse`
- `TreatmentTimelineResponse`
- `TreatmentStatusHistoryResponse`

### Analysis Inside Treatment

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/analyses` | `DOCTOR`, `ADMIN` with hospital access | Upload image and run analysis inside treatment context |

Request details:

- `multipart/form-data`
- field: `file`
- `patientId` and `doctorId` are not passed in this endpoint; backend derives context from treatment and JWT.

Main response DTO:

- `AnalysisCreateResponse`

Response contains:

- `analysisId`
- `jobId`
- `hospitalId`
- `treatmentId`
- `status`
- `diagnosisClass`

### Analysis Jobs

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/hospitals/{hospitalId}/analysis-jobs/{jobId}` | Authenticated hospital member | Get SVM/analysis job status and result metadata |

Main response DTO:

- `AnalysisJobResponse`

Frontend usage:

- after creating analysis inside treatment, read `jobId` from `AnalysisCreateResponse`;
- poll this endpoint until job status becomes terminal.

### SVM Model Registry

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `GET` | `/api/svm/models` | `ADMIN` | Get registered SVM model versions |
| `GET` | `/api/svm/models/{modelVersionId}/metrics` | `ADMIN` | Get all metrics for model version |
| `GET` | `/api/svm/models/{modelVersionId}/metrics?split={split}` | `ADMIN` | Get metrics filtered by dataset split |

Supported split filter:

- `TRAIN`
- `VALIDATION`
- `TEST`

Main response DTOs:

- `SvmModelVersionResponse`
- `SvmModelMetricResponse`

### SVM Research Experiments

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/svm/experiments/split-preview` | `ADMIN` | Preview train/validation/test split for SVM research pipeline |

Main request DTO:

- `SvmExperimentRequest`

Main response DTO:

- `SvmExperimentResponse`

### Treatment Dynamics, Conclusions, And Reports

| Method | Endpoint | Access | Purpose |
| --- | --- | --- | --- |
| `POST` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/comparisons` | Authenticated hospital member | Create comparison between analyses inside treatment |
| `GET` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/comparisons` | Authenticated hospital member | Get treatment comparisons |
| `PUT` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/conclusion` | Authenticated hospital doctor/admin | Create or update treatment conclusion |
| `GET` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/conclusion` | Authenticated hospital member | Get treatment conclusion |
| `GET` | `/api/hospitals/{hospitalId}/treatments/{treatmentId}/report` | Authenticated hospital member | Get aggregated treatment report |

Main request DTOs:

- `AnalysisComparisonCreateRequest`
- `TreatmentConclusionRequest`

Main response DTOs:

- `AnalysisComparisonResponse`
- `TreatmentConclusionResponse`
- `TreatmentReportResponse`

Frontend usage:

- treatment page should use `/report` as a high-level source for timeline/report screen;
- `/comparisons` is used for explicit analysis-to-analysis dynamics;
- `/conclusion` is used when doctor finalizes or updates medical conclusion for treatment.

## 3. Production Readiness Notes For Frontend

Currently available for frontend development:

- Auth/login/profile flow
- Legacy patient/doctor analysis screens
- Hospital selection and membership screens
- Treatment creation/list/timeline screens
- Image upload inside treatment
- Job status polling
- SVM model/metrics admin screens
- Treatment comparisons/conclusion/report screens

Currently limited in production:

- SVM preload is disabled, so image-analysis/SVM behavior must be verified separately on the deployed server.
- Mail credentials are empty, so doctor credential email delivery may fail until SMTP credentials are configured.
- Azure Blob is not connected with a real production connection string; local storage is the practical production storage path for now.
- CORS may need an update after the frontend domain is selected.
- Swagger UI should be checked separately at `/swagger-ui/index.html`; if unavailable, Springdoc configuration/dependency must be added or fixed.

