import { Routes } from '@angular/router';
import { AuthGuard } from '@core/guards/auth.guard';

// Auth
import { LoginComponent }          from '@features/auth/login/login.component';
import { RegisterComponent }       from '@features/auth/register/register.component';
import { ForgotPasswordComponent }  from '@features/auth/forgot-password/forgot-password.component';
import { ResetPasswordComponent }   from '@features/auth/reset-password/reset-password.component';
import { AcceptInviteComponent }    from '@features/auth/accept-invite/accept-invite.component';

// Dashboards
import { PatientDashboardComponent } from '@features/patient/patient-dashboard/patient-dashboard.component';
import { DoctorDashboardComponent }  from '@features/doctor/doctor-dashboard/doctor-dashboard.component';
import { UsersDashboardComponent }   from '@features/admin/users-dashboard/users-dashboard.component';
import { DummyComponent }            from '@features/misc/dummy/dummy.component';

// Doctor
import { PatientsTableComponent }      from '@features/doctor/patients-table/patients-table.component';
import { AnalysesTableComponent }      from '@features/doctor/analyses-table/analyses-table.component';
import { PatientDetailsPageComponent } from '@features/doctor/patient-details-page/patient-details-page.component';
import { AnalysisPageComponent }       from '@features/doctor/analysis-page/analysis-page.component';

// Patient
import { ResultDetailsPageComponent } from '@features/patient/result-details-page/result-details-page.component';

// Profile
import { UserProfileComponent } from '@features/profile/user-profile/user-profile.component';

// Hospitals
import { HospitalSelectComponent }      from '@features/hospitals/hospital-select/hospital-select.component';
import { HospitalAdminComponent }       from '@features/admin/hospital-admin/hospital-admin.component';
import { HospitalMembershipsComponent } from '@features/admin/hospital-memberships/hospital-memberships.component';

// Treatments
import { TreatmentListComponent }    from '@features/treatments/treatment-list/treatment-list.component';
import { TreatmentDetailsComponent } from '@features/treatments/treatment-details/treatment-details.component';
import { TreatmentReportComponent }  from '@features/treatments/treatment-report/treatment-report.component';

// Admin
import { SvmModelsComponent }  from '@features/admin/svm-models/svm-models.component';
import { AuditLogComponent }   from '@features/admin/audit-log/audit-log.component';

// Research
import { DatasetListComponent }       from '@features/research/dataset-list/dataset-list.component';
import { DatasetDetailsComponent }    from '@features/research/dataset-details/dataset-details.component';
import { ExperimentListComponent }    from '@features/research/experiment-list/experiment-list.component';
import { ExperimentDetailsComponent } from '@features/research/experiment-details/experiment-details.component';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // Public
  { path: 'login',           component: LoginComponent },
  { path: 'register',        component: RegisterComponent },
  { path: 'forgot-password',   component: ForgotPasswordComponent },
  { path: 'reset-password',    component: ResetPasswordComponent },
  { path: 'invite/accept',     component: AcceptInviteComponent },

  { path: 'dashboard', component: DummyComponent, canActivate: [AuthGuard] },

  // Role dashboards
  { path: 'dashboard/patient', component: PatientDashboardComponent, canActivate: [AuthGuard], data: { roles: ['PATIENT'] } },
  { path: 'dashboard/doctor',  component: DoctorDashboardComponent,  canActivate: [AuthGuard], data: { roles: ['DOCTOR']  } },
  { path: 'dashboard/admin',   component: UsersDashboardComponent,   canActivate: [AuthGuard], data: { roles: ['ADMIN']   } },

  // Shared protected
  { path: 'profile', component: UserProfileComponent, canActivate: [AuthGuard] },

  // Doctor routes
  { path: 'doctor/patients',                              component: PatientsTableComponent,      canActivate: [AuthGuard], data: { roles: ['DOCTOR'] } },
  { path: 'doctor/analyses',                              component: AnalysesTableComponent,      canActivate: [AuthGuard], data: { roles: ['DOCTOR', 'ADMIN'] } },
  { path: 'doctor/patients/:id',                          component: PatientDetailsPageComponent, canActivate: [AuthGuard], data: { roles: ['DOCTOR'] } },
  { path: 'doctor/patients/:id/analyses/:analysesId',     component: AnalysisPageComponent,       canActivate: [AuthGuard], data: { roles: ['DOCTOR'] } },

  // Patient routes
  { path: 'results/:id', component: ResultDetailsPageComponent, canActivate: [AuthGuard], data: { roles: ['PATIENT'] } },

  // Hospital & Treatment
  { path: 'hospitals',                                              component: HospitalSelectComponent,      canActivate: [AuthGuard] },
  { path: 'hospitals/:hospitalId/memberships',                      component: HospitalMembershipsComponent, canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'hospitals/:hospitalId/treatments',                       component: TreatmentListComponent,       canActivate: [AuthGuard] },
  { path: 'hospitals/:hospitalId/treatments/:treatmentId',          component: TreatmentDetailsComponent,    canActivate: [AuthGuard] },
  { path: 'hospitals/:hospitalId/treatments/:treatmentId/report',   component: TreatmentReportComponent,     canActivate: [AuthGuard] },

  // Admin
  { path: 'admin/hospitals',   component: HospitalAdminComponent, canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'admin/svm-models',  component: SvmModelsComponent,     canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'admin/audit-log',   component: AuditLogComponent,      canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },

  // Research
  { path: 'research/datasets',                         component: DatasetListComponent,       canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'research/datasets/:datasetId',              component: DatasetDetailsComponent,    canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'research/experiments',                      component: ExperimentListComponent,    canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
  { path: 'research/experiments/:experimentId',        component: ExperimentDetailsComponent, canActivate: [AuthGuard], data: { roles: ['ADMIN'] } },
];
