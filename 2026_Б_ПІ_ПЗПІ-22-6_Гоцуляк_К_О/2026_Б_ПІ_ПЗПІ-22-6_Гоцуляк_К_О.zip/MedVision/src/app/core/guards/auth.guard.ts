import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router, UrlTree } from '@angular/router';
import { AuthService } from '@core/services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean | UrlTree {
    const token = this.authService.getToken();
    if (!token) return this.router.parseUrl('/login');

    const allowedRoles: string[] | undefined = route.data?.['roles'];
    if (!allowedRoles || allowedRoles.length === 0) return true;

    const user = this.authService.getUser();
    if (!user) return this.router.parseUrl('/login');

    const userRole = (user.userRole || user.role || '').toUpperCase();
    if (allowedRoles.map((r: string) => r.toUpperCase()).includes(userRole)) return true;

    // Redirect to the user's own dashboard instead of a blank page
    switch (userRole) {
      case 'PATIENT': return this.router.parseUrl('/dashboard/patient');
      case 'DOCTOR':  return this.router.parseUrl('/dashboard/doctor');
      case 'ADMIN':   return this.router.parseUrl('/dashboard/admin');
      default:        return this.router.parseUrl('/login');
    }
  }
}
