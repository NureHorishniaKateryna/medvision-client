import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private readonly baseUrl = `${environment.apiUrl}/doctor`;

  constructor(private http: HttpClient) {}

  getPatients(): Observable<any> {
    return this.http.get(`${this.baseUrl}/patients`);
  }

  getPatientById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/patients/${id}`);
  }

  // multipart/form-data — patientId and doctorId as form fields, not query params
  analyzeImage(patientId: number, doctorId: number, file: File): Observable<string> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('patientId', patientId.toString());
    formData.append('doctorId', doctorId.toString());
    return this.http.post(`${this.baseUrl}/images/analyze`, formData, { responseType: 'text' });
  }

  addAnalysisNote(analysesId: number, doctorId: number, note: {
    noteText: string;
    noteAreaX: number;
    noteAreaY: number;
    noteAreaWidth: number;
    noteAreaHeight: number;
  }): Observable<any> {
    return this.http.post(`${this.baseUrl}/analyses/${analysesId}/notes?doctorId=${doctorId}`, note);
  }

  getAnalysisById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis/${id}`);
  }

  getHeatmap(id: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/heatmap/${id}`, { responseType: 'blob' });
  }
}
