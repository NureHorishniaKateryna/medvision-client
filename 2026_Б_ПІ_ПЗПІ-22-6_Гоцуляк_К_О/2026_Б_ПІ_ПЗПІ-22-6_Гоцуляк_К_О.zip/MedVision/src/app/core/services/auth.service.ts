import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, catchError, of, switchMap, tap } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private baseUrl = `${environment.apiUrl}/auth`;

  // Used by auth.interceptor to coordinate concurrent 401 retries
  isRefreshing = false;
  refreshTokenSubject = new BehaviorSubject<string | null>(null);

  constructor(private http: HttpClient) {}

  // ── Registration ───────────────────────────────────────────────────────────

  registerPatient(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/patient`, data).pipe(
      switchMap(() => this.login({ email: data.email, password: data.password }))
    );
  }

  registerDoctor(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/doctor`, data).pipe(
      switchMap(() => this.login({ email: data.email, password: data.password }))
    );
  }

  registerAdmin(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/admin`, data).pipe(
      switchMap(() => this.login({ email: data.email, password: data.password }))
    );
  }

  // ── Login ──────────────────────────────────────────────────────────────────

  login(data: { email: string; password: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, data).pipe(
      tap((res: any) => {
        if (res?.token) localStorage.setItem('token', res.token);
        if (res?.refreshToken) localStorage.setItem('refreshToken', res.refreshToken);
      }),
      switchMap(() => this.getProfile())
    );
  }

  // ── Profile ────────────────────────────────────────────────────────────────

  getProfile(): Observable<any> {
    return this.http.get(`${this.baseUrl}/profile`).pipe(
      tap(profile => localStorage.setItem('user', JSON.stringify(profile)))
    );
  }

  editPatient(data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/edit/patient`, data);
  }

  editDoctor(data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/edit/doctor`, data);
  }

  // ── Password reset ─────────────────────────────────────────────────────────

  forgotPassword(email: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/password/forgot`, { email });
  }

  resetPassword(token: string, newPassword: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/password/reset`, { token, newPassword });
  }

  // ── Token refresh ──────────────────────────────────────────────────────────

  refreshAccessToken(): Observable<any> {
    return this.http.post(`${this.baseUrl}/token/refresh`, {
      refreshToken: this.getRefreshToken()
    });
  }

  // ── Logout ─────────────────────────────────────────────────────────────────

  serverLogout(): Observable<any> {
    return this.http.post(`${this.baseUrl}/logout`, {
      refreshToken: this.getRefreshToken()
    }).pipe(
      catchError(() => of(null)),
      tap(() => this.clearSession())
    );
  }

  serverLogoutAll(): Observable<any> {
    return this.http.post(`${this.baseUrl}/logout-all`, {}).pipe(
      catchError(() => of(null)),
      tap(() => this.clearSession())
    );
  }

  // ── Token / session storage ────────────────────────────────────────────────

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getRefreshToken(): string | null {
    return localStorage.getItem('refreshToken');
  }

  setTokens(accessToken: string, refreshToken?: string): void {
    localStorage.setItem('token', accessToken);
    if (refreshToken) localStorage.setItem('refreshToken', refreshToken);
  }

  getUser(): any {
    const raw = localStorage.getItem('user');
    return raw ? JSON.parse(raw) : null;
  }

  clearSession(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
  }

  // Backward-compatible sync logout — clears local session without a server call.
  // Prefer serverLogout() for explicit user-triggered logout.
  logout(): void {
    this.clearSession();
  }
}
