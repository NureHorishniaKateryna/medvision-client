import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({ providedIn: 'root' })
export class TreatmentService {
  private readonly base = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // ── Treatments ─────────────────────────────────────────────────────────────

  createTreatment(hospitalId: number, data: { patientId: number; title?: string; description?: string }): Observable<any> {
    return this.http.post(`${this.base}/hospitals/${hospitalId}/treatments`, data);
  }

  getTreatments(hospitalId: number, filters?: { patientId?: number; doctorId?: number; status?: string }): Observable<any[]> {
    let params = new HttpParams();
    if (filters?.patientId) params = params.set('patientId', filters.patientId);
    if (filters?.doctorId) params = params.set('doctorId', filters.doctorId);
    if (filters?.status) params = params.set('status', filters.status);
    return this.http.get<any[]>(`${this.base}/hospitals/${hospitalId}/treatments`, { params });
  }

  getTreatmentTimeline(hospitalId: number, treatmentId: number): Observable<any> {
    return this.http.get(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}`);
  }

  closeTreatment(hospitalId: number, treatmentId: number, data?: { reason?: string }): Observable<any> {
    return this.http.patch(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/close`, data ?? {});
  }

  // ── Analysis inside treatment ──────────────────────────────────────────────

  createAnalysis(hospitalId: number, treatmentId: number, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/analyses`, formData);
  }

  getAnalysisJob(hospitalId: number, jobId: string): Observable<any> {
    return this.http.get(`${this.base}/hospitals/${hospitalId}/analysis-jobs/${jobId}`);
  }

  listAnalysisJobs(hospitalId: number, treatmentId?: number): Observable<any[]> {
    let params = new HttpParams();
    if (treatmentId != null) params = params.set('treatmentId', treatmentId);
    return this.http.get<any[]>(`${this.base}/hospitals/${hospitalId}/analysis-jobs`, { params });
  }

  retryAnalysisJob(hospitalId: number, jobId: number): Observable<any> {
    return this.http.post(`${this.base}/hospitals/${hospitalId}/analysis-jobs/${jobId}/retry`, {});
  }

  // ── Comparisons ────────────────────────────────────────────────────────────

  createComparison(hospitalId: number, treatmentId: number, data: { fromAnalysisId: number; toAnalysisId: number }): Observable<any> {
    return this.http.post(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/comparisons`, data);
  }

  getComparisons(hospitalId: number, treatmentId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/comparisons`);
  }

  // ── Conclusion ─────────────────────────────────────────────────────────────

  setConclusion(hospitalId: number, treatmentId: number, data: { conclusionText: string }): Observable<any> {
    return this.http.put(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/conclusion`, data);
  }

  getConclusion(hospitalId: number, treatmentId: number): Observable<any> {
    return this.http.get(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/conclusion`);
  }

  // ── Report ─────────────────────────────────────────────────────────────────

  getTreatmentReport(hospitalId: number, treatmentId: number): Observable<any> {
    return this.http.get(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/report`);
  }

  // ── Analysis Review ────────────────────────────────────────────────────────

  getReview(hospitalId: number, treatmentId: number, analysisId: number): Observable<any> {
    return this.http.get(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/analyses/${analysisId}/review`);
  }

  submitReview(hospitalId: number, treatmentId: number, analysisId: number, body: { decision: string; correctedClass?: number; comment?: string }): Observable<any> {
    return this.http.put(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/analyses/${analysisId}/review`, body);
  }

  getExplanation(hospitalId: number, treatmentId: number, analysisId: number): Observable<any> {
    return this.http.get(`${this.base}/hospitals/${hospitalId}/treatments/${treatmentId}/analyses/${analysisId}/explanation`);
  }
}
