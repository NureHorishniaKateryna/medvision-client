import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({ providedIn: 'root' })
export class ResearchService {
  private readonly base = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // ── Datasets ───────────────────────────────────────────────────────────────

  getDatasets(status?: string): Observable<any[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    return this.http.get<any[]>(`${this.base}/research/datasets`, { params });
  }

  createDataset(data: { name: string; version: string; description?: string }): Observable<any> {
    return this.http.post(`${this.base}/research/datasets`, data);
  }

  getDataset(datasetId: number): Observable<any> {
    return this.http.get(`${this.base}/research/datasets/${datasetId}`);
  }

  addItem(datasetId: number, classLabel: number, file: File, sourceAnalysisId?: number): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    let params = new HttpParams().set('classLabel', classLabel);
    if (sourceAnalysisId != null) params = params.set('sourceAnalysisId', sourceAnalysisId);
    return this.http.post(`${this.base}/research/datasets/${datasetId}/items`, formData, { params });
  }

  freezeDataset(datasetId: number): Observable<any> {
    return this.http.post(`${this.base}/research/datasets/${datasetId}/freeze`, {});
  }

  splitDataset(datasetId: number, body: { trainRatio: number; validationRatio: number; testRatio: number; seed: number }): Observable<any> {
    return this.http.post(`${this.base}/research/datasets/${datasetId}/split`, body);
  }

  labelItem(itemId: number, classLabel?: number, reason?: string): Observable<any> {
    return this.http.put(`${this.base}/research/dataset-items/${itemId}/label`, { classLabel, reason });
  }

  // ── Reviewed cases ─────────────────────────────────────────────────────────

  getReviewedCases(opts?: { modelVersionId?: number; decision?: string; page?: number; size?: number }): Observable<any> {
    let params = new HttpParams()
      .set('page', opts?.page ?? 0)
      .set('size', opts?.size ?? 50);
    if (opts?.modelVersionId) params = params.set('modelVersionId', opts.modelVersionId);
    if (opts?.decision) params = params.set('decision', opts.decision);
    return this.http.get(`${this.base}/research/reviewed-cases`, { params });
  }

  exportFromReviews(datasetId: number, analysisIds: number[]): Observable<any[]> {
    return this.http.post<any[]>(`${this.base}/research/datasets/${datasetId}/items/from-reviews`, { analysisIds });
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  buildDataset(): Observable<string> {
    return this.http.post(`${this.base}/dataset/build`, null, { responseType: 'text' });
  }

  // ── SVM Experiments ────────────────────────────────────────────────────────

  getExperiments(filters?: { datasetId?: number; status?: string; modelType?: string }): Observable<any[]> {
    let params = new HttpParams();
    if (filters?.datasetId) params = params.set('datasetId', filters.datasetId);
    if (filters?.status)    params = params.set('status', filters.status);
    if (filters?.modelType) params = params.set('modelType', filters.modelType);
    return this.http.get<any[]>(`${this.base}/research/svm-experiments`, { params });
  }

  createExperiment(body: {
    datasetId: number; modelType: string; kernelType: string;
    c: number; gamma?: number; multiclassStrategy: string;
    featureSet: string; seed: number;
  }): Observable<any> {
    return this.http.post(`${this.base}/research/svm-experiments`, body);
  }

  getExperiment(experimentId: number): Observable<any> {
    return this.http.get(`${this.base}/research/svm-experiments/${experimentId}`);
  }

  runExperiment(experimentId: number): Observable<any> {
    return this.http.post(`${this.base}/research/svm-experiments/${experimentId}/run`, {});
  }

  getExperimentMetrics(experimentId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/research/svm-experiments/${experimentId}/metrics`);
  }

  getConfusionMatrix(experimentId: number): Observable<any> {
    return this.http.get(`${this.base}/research/svm-experiments/${experimentId}/confusion-matrix`);
  }

  compareExperiments(ids: number[]): Observable<Record<string, any[]>> {
    let params = new HttpParams();
    ids.forEach(id => { params = params.append('ids', id); });
    return this.http.get<Record<string, any[]>>(`${this.base}/research/svm-experiments/compare`, { params });
  }
}
