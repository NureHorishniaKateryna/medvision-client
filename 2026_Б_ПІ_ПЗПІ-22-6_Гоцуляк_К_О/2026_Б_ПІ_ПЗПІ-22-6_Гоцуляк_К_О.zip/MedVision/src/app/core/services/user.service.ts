import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private readonly baseUrl = `${environment.apiUrl}/users`;

  constructor(private http: HttpClient) {}

  // Отримати список усіх користувачів
  getAllUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  // Отримати користувача за ID
  getUserById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  // Змінити роль користувача
  updateUserRole(id: number, newRole: string): Observable<any> {
    return this.http.patch(`${this.baseUrl}/${id}/role`, { newRole });
  }

  // Видалити користувача
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  // Заблокувати / розблокувати акаунт
  updateAccountStatus(userId: number, status: 'ACTIVE' | 'LOCKED' | 'DISABLED' | 'PENDING_VERIFICATION', reason: string): Observable<any> {
    return this.http.patch(`${environment.apiUrl}/admin/users/${userId}/account-status`, { status, reason });
  }

  // Аудит-лог
  getAuditEvents(page = 0, size = 20): Observable<any> {
    return this.http.get(`${environment.apiUrl}/admin/audit-events`, { params: { page, size } });
  }
}
