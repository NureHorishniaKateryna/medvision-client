import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({ providedIn: 'root' })
export class HospitalService {
  private readonly base = environment.apiUrl;

  private activeHospitalSubject = new BehaviorSubject<any>(this.loadActiveHospital());
  activeHospital$ = this.activeHospitalSubject.asObservable();

  constructor(private http: HttpClient) {}

  // ── Admin ──────────────────────────────────────────────────────────────────

  createHospital(data: { name: string; address?: string }): Observable<any> {
    return this.http.post(`${this.base}/admin/hospitals`, data);
  }

  getAdminHospitals(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/admin/hospitals`);
  }

  updateHospital(hospitalId: number, data: { name?: string; address?: string }): Observable<any> {
    return this.http.patch(`${this.base}/admin/hospitals/${hospitalId}`, data);
  }

  // ── User context ───────────────────────────────────────────────────────────

  getMyHospitals(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/hospitals/my`);
  }

  selectHospital(hospitalId: number): Observable<any> {
    return this.http.post(`${this.base}/hospitals/${hospitalId}/select`, {}).pipe(
      tap((res: any) => {
        const hospital = { id: hospitalId, ...res };
        localStorage.setItem('activeHospital', JSON.stringify(hospital));
        this.activeHospitalSubject.next(hospital);
      })
    );
  }

  // ── Memberships ────────────────────────────────────────────────────────────

  addMembership(hospitalId: number, data: { userId: number; hospitalRole: string }): Observable<any> {
    return this.http.post(`${this.base}/hospitals/${hospitalId}/memberships`, data);
  }

  getMemberships(hospitalId: number, role?: string): Observable<any[]> {
    let params = new HttpParams();
    if (role) params = params.set('role', role);
    return this.http.get<any[]>(`${this.base}/hospitals/${hospitalId}/memberships`, { params });
  }

  updateMembershipStatus(hospitalId: number, membershipId: number, status: string): Observable<any> {
    return this.http.patch(
      `${this.base}/hospitals/${hospitalId}/memberships/${membershipId}/status`,
      { status }
    );
  }

  // ── Local helpers ──────────────────────────────────────────────────────────

  getActiveHospital(): any {
    return this.activeHospitalSubject.value;
  }

  clearActiveHospital(): void {
    localStorage.removeItem('activeHospital');
    this.activeHospitalSubject.next(null);
  }

  private loadActiveHospital(): any {
    const raw = localStorage.getItem('activeHospital');
    return raw ? JSON.parse(raw) : null;
  }
}
