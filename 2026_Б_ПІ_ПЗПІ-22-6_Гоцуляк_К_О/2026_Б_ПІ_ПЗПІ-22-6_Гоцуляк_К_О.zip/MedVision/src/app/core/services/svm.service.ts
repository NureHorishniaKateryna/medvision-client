import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

@Injectable({ providedIn: 'root' })
export class SvmService {
  private readonly base = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getModels(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/svm/models`);
  }

  getModelMetrics(modelVersionId: number, split?: string): Observable<any[]> {
    let params = new HttpParams();
    if (split) params = params.set('split', split);
    return this.http.get<any[]>(`${this.base}/svm/models/${modelVersionId}/metrics`, { params });
  }

  getActiveModel(modelType: 'FULL_IMAGE' | 'PATCH_BASED'): Observable<any> {
    return this.http.get(`${this.base}/svm/models/active`, { params: { modelType } });
  }

  activateModel(modelVersionId: number): Observable<any> {
    return this.http.post(`${this.base}/svm/models/${modelVersionId}/activate`, {});
  }

  archiveModel(modelVersionId: number): Observable<any> {
    return this.http.post(`${this.base}/svm/models/${modelVersionId}/archive`, {});
  }

  registerModel(body: { experimentId: number; name: string; version: string }): Observable<any> {
    return this.http.post(`${this.base}/svm/models`, body);
  }

  trainModels(datasetPath: string): Observable<string> {
    return this.http.post(`${this.base}/svm/train`, null, { params: { datasetPath }, responseType: 'text' });
  }

  previewSplit(data: any): Observable<any> {
    return this.http.post(`${this.base}/svm/experiments/split-preview`, data);
  }
}
