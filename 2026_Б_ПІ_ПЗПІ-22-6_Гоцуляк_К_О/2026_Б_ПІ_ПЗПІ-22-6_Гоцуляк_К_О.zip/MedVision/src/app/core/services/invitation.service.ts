import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

export interface DoctorInvitationRequest {
  hospitalId: number;
  email: string;
  name: string;
  hospitalRole: 'DOCTOR' | 'PATIENT' | 'HOSPITAL_ADMIN';
  position?: string;
  department?: string;
  licenseNumber?: string;
}

export interface DoctorInvitationResponse {
  invitationId: number;
  token: string;
  expiresAt: string;
}

@Injectable({ providedIn: 'root' })
export class InvitationService {
  private http = inject(HttpClient);
  private baseUrl = environment.apiUrl;

  inviteDoctor(data: DoctorInvitationRequest): Observable<DoctorInvitationResponse> {
    return this.http.post<DoctorInvitationResponse>(`${this.baseUrl}/admin/invitations/doctors`, data);
  }

  acceptInvitation(token: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/auth/invitations/accept`, { token, password });
  }
}
