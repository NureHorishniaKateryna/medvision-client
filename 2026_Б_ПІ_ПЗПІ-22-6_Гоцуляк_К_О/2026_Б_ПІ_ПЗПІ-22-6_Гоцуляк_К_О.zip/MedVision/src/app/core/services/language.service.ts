import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

export type AppLang = 'en' | 'uk' | 'de' | 'fr' | 'pl';

export interface LangOption {
  code: AppLang;
  label: string;
  flag: string;
}

@Injectable({ providedIn: 'root' })
export class LanguageService {
  private readonly STORAGE_KEY = 'lang';
  readonly supported: AppLang[] = ['en', 'uk', 'de', 'fr', 'pl'];

  readonly options: LangOption[] = [
    { code: 'en', label: 'English',    flag: '🇬🇧' },
    { code: 'uk', label: 'Українська', flag: '🇺🇦' },
    { code: 'de', label: 'Deutsch',    flag: '🇩🇪' },
    { code: 'fr', label: 'Français',   flag: '🇫🇷' },
    { code: 'pl', label: 'Polski',     flag: '🇵🇱' },
  ];

  constructor(private translate: TranslateService) {}

  init(): void {
    const saved = localStorage.getItem(this.STORAGE_KEY) as AppLang | null;
    const lang: AppLang = saved && this.supported.includes(saved) ? saved : 'en';
    this.translate.addLangs(this.supported);
    this.translate.setDefaultLang('en');
    this.translate.use(lang);
  }

  get current(): AppLang {
    return (this.translate.currentLang ?? 'en') as AppLang;
  }

  set(lang: AppLang): void {
    this.translate.use(lang);
    localStorage.setItem(this.STORAGE_KEY, lang);
  }

  toggle(): void {
    const idx = this.supported.indexOf(this.current);
    const next = this.supported[(idx + 1) % this.supported.length];
    this.set(next);
  }
}
