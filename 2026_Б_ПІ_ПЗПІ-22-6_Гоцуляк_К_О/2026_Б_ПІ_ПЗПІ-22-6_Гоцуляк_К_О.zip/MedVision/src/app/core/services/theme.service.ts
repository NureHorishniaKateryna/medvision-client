import { Injectable } from '@angular/core';

export type AppTheme = 'light' | 'dark';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly STORAGE_KEY = 'theme';
  private _current: AppTheme = 'light';

  init(): void {
    const saved = localStorage.getItem(this.STORAGE_KEY) as AppTheme | null;
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    this._current = saved ?? (prefersDark ? 'dark' : 'light');
    this.apply();
  }

  get current(): AppTheme { return this._current; }
  get isDark(): boolean    { return this._current === 'dark'; }

  toggle(): void {
    this._current = this._current === 'light' ? 'dark' : 'light';
    this.apply();
    localStorage.setItem(this.STORAGE_KEY, this._current);
  }

  private apply(): void {
    document.body.classList.toggle('dark-theme', this._current === 'dark');
  }
}
