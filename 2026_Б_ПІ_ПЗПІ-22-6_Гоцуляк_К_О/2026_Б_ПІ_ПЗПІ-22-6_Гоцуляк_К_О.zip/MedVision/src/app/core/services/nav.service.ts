import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class NavService {
  private openSubject = new BehaviorSubject<boolean>(false);
  isOpen$ = this.openSubject.asObservable();

  toggle(): void { this.openSubject.next(!this.openSubject.value); }
  open(): void   { this.openSubject.next(true); }
  close(): void  { this.openSubject.next(false); }
}
