import {
  HttpErrorResponse,
  HttpHandlerFn,
  HttpInterceptorFn,
  HttpRequest,
} from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import {
  BehaviorSubject,
  Observable,
  catchError,
  filter,
  switchMap,
  take,
  throwError,
} from 'rxjs';
import { AuthService } from '@core/services/auth.service';

// URLs that must never trigger the 401 → refresh cycle
const AUTH_SKIP_URLS = [
  '/auth/login',
  '/auth/register',
  '/auth/token/refresh',
  '/auth/logout',
];

function isAuthSkipUrl(url: string): boolean {
  return AUTH_SKIP_URLS.some(path => url.includes(path));
}

function addBearer(req: HttpRequest<unknown>, token: string): HttpRequest<unknown> {
  return req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
}

function handle401(
  authService: AuthService,
  router: Router,
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<any> {
  // Another request is already refreshing — queue and wait
  if (authService.isRefreshing) {
    return authService.refreshTokenSubject.pipe(
      filter(token => token !== null),
      take(1),
      switchMap(token => next(addBearer(req, token!)))
    );
  }

  authService.isRefreshing = true;
  authService.refreshTokenSubject.next(null);

  if (!authService.getRefreshToken()) {
    authService.isRefreshing = false;
    authService.clearSession();
    router.navigate(['/login']);
    return throwError(() => new Error('No refresh token available'));
  }

  return authService.refreshAccessToken().pipe(
    switchMap((res: any) => {
      authService.isRefreshing = false;
      authService.setTokens(res.token, res.refreshToken);
      authService.refreshTokenSubject.next(res.token);
      return next(addBearer(req, res.token));
    }),
    catchError(err => {
      authService.isRefreshing = false;
      authService.clearSession();
      router.navigate(['/login']);
      return throwError(() => err);
    })
  );
}

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  const token = authService.getToken();
  const authReq = token && !isAuthSkipUrl(req.url)
    ? addBearer(req, token)
    : req;

  return next(authReq).pipe(
    catchError((err: HttpErrorResponse) => {
      if (err.status === 401 && !isAuthSkipUrl(req.url)) {
        return handle401(authService, router, req, next);
      }
      return throwError(() => err);
    })
  );
};
