import { Component, Input, OnInit, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '@core/services/auth.service';
import { HospitalService } from '@core/services/hospital.service';
import { PatientService } from '@core/services/patient.service';
import { NavService } from '@core/services/nav.service';
import { MatTooltip } from '@angular/material/tooltip';
import { MatMenu, MatMenuItem, MatMenuTrigger } from '@angular/material/menu';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-page-header',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule, MatButtonModule, MatTooltip, MatMenuTrigger, MatMenu, MatMenuItem, TranslateModule],
  templateUrl: './page-header.component.html',
  styleUrl: './page-header.component.scss'
})
export class PageHeaderComponent implements OnInit {
  @Input() backLink?: any;

  role = '';
  fullName = '';
  userInitials = '';
  unviewedCount = 0;
  unviewedAnalyses: any[] = [];
  activeHospitalName = '';

  private authService = inject(AuthService);
  private hospitalService = inject(HospitalService);
  private patientService = inject(PatientService);
  private navService = inject(NavService);
  private router = inject(Router);

  ngOnInit(): void {
    const user = this.authService.getUser();
    if (user) {
      this.fullName = user.userName || `${user.name || ''}`.trim();
      this.role = this.mapRole(user.userRole || user.role);
      this.userInitials = this.getInitials(this.fullName);

      if ((user.userRole || user.role)?.toUpperCase() === 'PATIENT') {
        this.patientService.getUnviewedAnalyses().subscribe(analyses => {
          this.unviewedAnalyses = analyses;
          this.unviewedCount = analyses.length;
        });
      }
    }

    this.hospitalService.activeHospital$.subscribe(h => {
      this.activeHospitalName = h?.hospitalName ?? h?.name ?? '';
    });
  }

  markOneAndNavigate(id: number): void {
    this.patientService.markAnalysisAsViewed(id).subscribe(() => {
      window.location.href = `/results/${id}`;
    });
  }

  logout(): void {
    this.authService.serverLogout().subscribe({
      complete: () => {
        this.hospitalService.clearActiveHospital();
        this.router.navigate(['/login']);
      }
    });
  }

  logoutAll(): void {
    this.authService.serverLogoutAll().subscribe({
      complete: () => {
        this.hospitalService.clearActiveHospital();
        this.router.navigate(['/login']);
      }
    });
  }

  toggleNav(): void { this.navService.toggle(); }

  goToHospitals(): void {
    this.router.navigate(['/hospitals']);
  }

  private getInitials(name: string): string {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  private mapRole(role: string): string {
    switch (role?.toUpperCase()) {
      case 'DOCTOR': return 'Doctor';
      case 'PATIENT': return 'Patient';
      case 'ADMIN': return 'Admin';
      default: return 'User';
    }
  }
}
