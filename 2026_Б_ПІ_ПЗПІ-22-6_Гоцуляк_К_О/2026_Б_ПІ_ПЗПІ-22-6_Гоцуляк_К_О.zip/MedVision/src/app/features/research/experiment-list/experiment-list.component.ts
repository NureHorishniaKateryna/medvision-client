import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TranslateModule } from '@ngx-translate/core';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { ResearchService } from '@core/services/research.service';

@Component({
  selector: 'app-experiment-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './experiment-list.component.html',
  styleUrl: './experiment-list.component.scss',
})
export class ExperimentListComponent implements OnInit {
  private researchService = inject(ResearchService);
  private router = inject(Router);

  experiments: any[] = [];
  loading = true;
  statusFilter = '';

  frozenDatasets: any[] = [];
  loadingDatasets = true;

  showCreateForm = false;
  creating = false;
  createError = '';

  form = {
    datasetId: null as number | null,
    modelType: 'FULL_IMAGE',
    kernelType: 'RBF',
    c: 1.0,
    gamma: null as number | null,
    multiclassStrategy: 'ONE_VS_ONE',
    featureSet: 'full-image',
    seed: 42,
  };

  readonly modelTypes    = ['FULL_IMAGE', 'PATCH_BASED'];
  readonly kernelTypes   = ['LINEAR', 'POLYNOMIAL', 'RBF'];
  readonly strategies    = ['ONE_VS_ONE', 'ONE_VS_REST'];
  readonly statusFilters = ['', 'CREATED', 'RUNNING', 'COMPLETED', 'FAILED'];
  readonly featureSets   = ['full-image', 'patch-based', 'hog', 'lbp', 'hog+lbp', 'combined'];

  ngOnInit(): void {
    this.load();
    this.researchService.getDatasets('FROZEN').subscribe({
      next: data => { this.frozenDatasets = data ?? []; this.loadingDatasets = false; },
      error: () => { this.loadingDatasets = false; },
    });
  }

  load(): void {
    this.loading = true;
    this.researchService.getExperiments({ status: this.statusFilter || undefined }).subscribe({
      next: data => { this.experiments = data ?? []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  setFilter(f: string): void { this.statusFilter = f; this.load(); }

  open(e: any): void { this.router.navigate(['/research/experiments', e.experimentId]); }

  toggleCreate(): void { this.showCreateForm = !this.showCreateForm; this.createError = ''; }

  get gammaRequired(): boolean {
    return this.form.kernelType === 'POLYNOMIAL' || this.form.kernelType === 'RBF';
  }

  get formValid(): boolean {
    return !!(
      this.form.datasetId &&
      this.form.featureSet.trim() &&
      this.form.c > 0 &&
      (!this.gammaRequired || (this.form.gamma != null && this.form.gamma > 0))
    );
  }

  create(): void {
    if (!this.formValid) return;
    this.creating = true;
    this.createError = '';
    const body: any = {
      datasetId: this.form.datasetId,
      modelType: this.form.modelType,
      kernelType: this.form.kernelType,
      c: this.form.c,
      multiclassStrategy: this.form.multiclassStrategy,
      featureSet: this.form.featureSet.trim(),
      seed: this.form.seed,
    };
    if (this.form.gamma != null) body.gamma = this.form.gamma;
    this.researchService.createExperiment(body).subscribe({
      next: exp => {
        this.creating = false;
        this.router.navigate(['/research/experiments', exp.experimentId]);
      },
      error: () => { this.creating = false; this.createError = 'Failed to create experiment.'; },
    });
  }

  statusClass(s: string): string {
    switch (s) {
      case 'COMPLETED': return 'status--completed';
      case 'RUNNING':   return 'status--running';
      case 'FAILED':    return 'status--failed';
      default:          return 'status--created';
    }
  }

  statusIcon(s: string): string {
    switch (s) {
      case 'COMPLETED': return 'check_circle';
      case 'RUNNING':   return 'sync';
      case 'FAILED':    return 'error';
      default:          return 'schedule';
    }
  }
}
