import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TranslateModule } from '@ngx-translate/core';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { ResearchService } from '@core/services/research.service';

@Component({
  selector: 'app-dataset-details',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, MatTooltipModule, PageHeaderComponent, TranslateModule],
  templateUrl: './dataset-details.component.html',
  styleUrl: './dataset-details.component.scss',
})
export class DatasetDetailsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private researchService = inject(ResearchService);

  datasetId!: number;
  dataset: any = null;
  loading = true;

  activeTab: 'overview' | 'add' | 'reviews' | 'actions' = 'overview';

  // Add item
  addFile: File | null = null;
  addClassLabel: number | null = null;
  addSourceAnalysisId: number | null = null;
  adding = false;
  addSuccess = false;
  addError = '';

  // Freeze
  freezing = false;
  confirmFreeze = false;

  // Split
  trainRatio = 0.7;
  validationRatio = 0.15;
  testRatio = 0.15;
  splitSeed = 42;
  splitting = false;
  splitResult: any = null;
  splitError = '';

  // Reviewed cases
  reviews: any[] = [];
  loadingReviews = false;
  reviewDecisionFilter = '';
  selectedReviewIds: number[] = [];
  importing = false;
  importCount = 0;

  ngOnInit(): void {
    this.datasetId = +this.route.snapshot.paramMap.get('datasetId')!;
    this.load();
  }

  load(): void {
    this.loading = true;
    this.researchService.getDataset(this.datasetId).subscribe({
      next: d => { this.dataset = d; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  // ── Add item ───────────────────────────────────────────────────────────────

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.length) { this.addFile = input.files[0]; this.addError = ''; }
  }

  addItem(): void {
    if (!this.addFile || this.addClassLabel == null) return;
    this.adding = true;
    this.addError = '';
    this.addSuccess = false;
    this.researchService.addItem(
      this.datasetId,
      this.addClassLabel,
      this.addFile,
      this.addSourceAnalysisId ?? undefined
    ).subscribe({
      next: () => {
        this.adding = false;
        this.addSuccess = true;
        this.addFile = null;
        this.addClassLabel = null;
        this.addSourceAnalysisId = null;
        setTimeout(() => { this.addSuccess = false; }, 3000);
        this.load();
      },
      error: () => { this.adding = false; this.addError = 'Failed to add item.'; },
    });
  }

  // ── Freeze ─────────────────────────────────────────────────────────────────

  freezeClick(): void {
    if (this.confirmFreeze) {
      this.freeze();
    } else {
      this.confirmFreeze = true;
    }
  }

  private freeze(): void {
    this.confirmFreeze = false;
    this.freezing = true;
    this.researchService.freezeDataset(this.datasetId).subscribe({
      next: d => { this.dataset = d; this.freezing = false; },
      error: () => { this.freezing = false; },
    });
  }

  // ── Split ──────────────────────────────────────────────────────────────────

  get ratioSum(): number {
    return +((this.trainRatio + this.validationRatio + this.testRatio).toFixed(10));
  }

  get ratioValid(): boolean { return Math.abs(this.ratioSum - 1.0) < 0.001; }

  split(): void {
    if (!this.ratioValid) return;
    this.splitting = true;
    this.splitError = '';
    this.researchService.splitDataset(this.datasetId, {
      trainRatio: this.trainRatio,
      validationRatio: this.validationRatio,
      testRatio: this.testRatio,
      seed: this.splitSeed,
    }).subscribe({
      next: res => { this.splitResult = res; this.splitting = false; this.load(); },
      error: () => { this.splitError = 'Split failed.'; this.splitting = false; },
    });
  }

  splitCounts(): { label: string; count: number }[] {
    if (!this.splitResult?.counts) return [];
    return Object.entries(this.splitResult.counts).map(([label, count]) => ({ label, count: count as number }));
  }

  // ── Reviewed cases ─────────────────────────────────────────────────────────

  loadReviews(): void {
    this.loadingReviews = true;
    this.selectedReviewIds = [];
    this.researchService.getReviewedCases({
      decision: this.reviewDecisionFilter || undefined,
    }).subscribe({
      next: res => { this.reviews = res.content ?? []; this.loadingReviews = false; },
      error: () => { this.loadingReviews = false; },
    });
  }

  toggleReview(id: number): void {
    const idx = this.selectedReviewIds.indexOf(id);
    if (idx > -1) this.selectedReviewIds.splice(idx, 1);
    else this.selectedReviewIds.push(id);
  }

  isReviewSelected(id: number): boolean { return this.selectedReviewIds.includes(id); }

  selectAllReviews(): void { this.selectedReviewIds = this.reviews.map(r => r.analysisId); }
  clearReviewSelection(): void { this.selectedReviewIds = []; }

  importFromReviews(): void {
    if (!this.selectedReviewIds.length) return;
    this.importing = true;
    this.researchService.exportFromReviews(this.datasetId, this.selectedReviewIds).subscribe({
      next: items => {
        this.importCount = items?.length ?? 0;
        this.importing = false;
        this.selectedReviewIds = [];
        this.load();
      },
      error: () => { this.importing = false; },
    });
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  get isDraft(): boolean  { return this.dataset?.status === 'DRAFT'; }
  get isFrozen(): boolean { return this.dataset?.status === 'FROZEN'; }

  distributionEntries(dist: any): { label: string; count: number; pct: number }[] {
    if (!dist) return [];
    const total = Object.values(dist).reduce((s: number, v) => s + (v as number), 0) as number;
    return Object.entries(dist).map(([label, count]) => ({
      label,
      count: count as number,
      pct: total > 0 ? Math.round((count as number) / total * 100) : 0,
    }));
  }

  decisionLabel(d: string): string {
    switch (d) {
      case 'CONFIRMED': return 'Confirmed';
      case 'CORRECTED': return 'Corrected';
      case 'REJECTED':  return 'Rejected';
      default: return d;
    }
  }
}
