import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TranslateModule } from '@ngx-translate/core';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { ResearchService } from '@core/services/research.service';

@Component({
  selector: 'app-dataset-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './dataset-list.component.html',
  styleUrl: './dataset-list.component.scss',
})
export class DatasetListComponent implements OnInit {
  private researchService = inject(ResearchService);
  private router = inject(Router);

  datasets: any[] = [];
  loading = true;
  statusFilter = '';

  showCreateForm = false;
  createName = '';
  createVersion = '';
  createDescription = '';
  creating = false;
  createError = '';

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.researchService.getDatasets(this.statusFilter || undefined).subscribe({
      next: data => { this.datasets = data ?? []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  setFilter(f: string): void { this.statusFilter = f; this.load(); }

  openDataset(d: any): void { this.router.navigate(['/research/datasets', d.datasetId]); }

  toggleCreate(): void {
    this.showCreateForm = !this.showCreateForm;
    this.createError = '';
  }

  create(): void {
    if (!this.createName.trim() || !this.createVersion.trim()) return;
    this.creating = true;
    this.createError = '';
    this.researchService.createDataset({
      name: this.createName.trim(),
      version: this.createVersion.trim(),
      description: this.createDescription.trim() || undefined,
    }).subscribe({
      next: (d) => {
        this.creating = false;
        this.showCreateForm = false;
        this.createName = '';
        this.createVersion = '';
        this.createDescription = '';
        this.router.navigate(['/research/datasets', d.datasetId]);
      },
      error: () => { this.creating = false; this.createError = 'Failed to create dataset.'; },
    });
  }

  distributionEntries(dist: any): { label: string; count: number }[] {
    if (!dist) return [];
    return Object.entries(dist).map(([label, count]) => ({ label, count: count as number }));
  }

  totalDist(dist: any): number {
    if (!dist) return 0;
    return Object.values(dist).reduce((s: number, v) => s + (v as number), 0);
  }
}
