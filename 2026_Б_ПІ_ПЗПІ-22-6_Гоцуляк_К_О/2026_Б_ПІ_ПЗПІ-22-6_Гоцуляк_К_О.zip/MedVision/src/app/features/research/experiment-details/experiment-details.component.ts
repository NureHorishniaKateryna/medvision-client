import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { interval, Subscription, switchMap, takeWhile } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { ResearchService } from '@core/services/research.service';
import { SvmService } from '@core/services/svm.service';

@Component({
  selector: 'app-experiment-details',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, MatTooltipModule, PageHeaderComponent, TranslateModule],
  templateUrl: './experiment-details.component.html',
  styleUrl: './experiment-details.component.scss',
})
export class ExperimentDetailsComponent implements OnInit, OnDestroy {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private researchService = inject(ResearchService);
  private svmService = inject(SvmService);

  experimentId!: number;
  experiment: any = null;
  loading = true;

  activeTab: 'metrics' | 'matrix' | 'compare' = 'metrics';

  // Metrics
  metrics: any[] = [];
  loadingMetrics = false;

  // Confusion matrix
  matrix: any = null;
  loadingMatrix = false;

  // Run
  running = false;

  // Register as model
  registerName = '';
  registerVersion = '';
  registering = false;
  registerError = '';

  // Compare
  compareInput = '';
  comparing = false;
  compareResult: Record<string, any[]> | null = null;
  compareError = '';

  private pollSub?: Subscription;

  ngOnInit(): void {
    this.experimentId = +this.route.snapshot.paramMap.get('experimentId')!;
    this.load();
  }

  ngOnDestroy(): void { this.pollSub?.unsubscribe(); }

  load(): void {
    this.loading = true;
    this.researchService.getExperiment(this.experimentId).subscribe({
      next: e => {
        this.experiment = e;
        this.loading = false;
        if (e.status === 'RUNNING') this.startPolling();
        if (e.status === 'COMPLETED') {
          this.loadMetrics();
          this.loadMatrix();
        }
      },
      error: () => { this.loading = false; },
    });
  }

  private startPolling(): void {
    this.pollSub?.unsubscribe();
    this.pollSub = interval(4000).pipe(
      switchMap(() => this.researchService.getExperiment(this.experimentId)),
      takeWhile((e: any) => e.status === 'RUNNING', true),
    ).subscribe({
      next: (e: any) => {
        this.experiment = e;
        if (e.status === 'COMPLETED') { this.loadMetrics(); this.loadMatrix(); }
      },
    });
  }

  get registerValid(): boolean {
    return !!(this.registerName.trim() && this.registerVersion.trim());
  }

  registerModel(): void {
    if (!this.registerValid) return;
    this.registering = true;
    this.registerError = '';
    this.svmService.registerModel({
      experimentId: this.experimentId,
      name: this.registerName.trim(),
      version: this.registerVersion.trim(),
    }).subscribe({
      next: () => {
        this.registering = false;
        this.router.navigate(['/admin/svm-models']);
      },
      error: () => {
        this.registering = false;
        this.registerError = 'RESEARCH.EXPERIMENT.REGISTER_ERROR';
      },
    });
  }

  run(): void {
    this.running = true;
    this.researchService.runExperiment(this.experimentId).subscribe({
      next: e => {
        this.experiment = e;
        this.running = false;
        if (e.status === 'RUNNING') this.startPolling();
      },
      error: () => { this.running = false; },
    });
  }

  loadMetrics(): void {
    this.loadingMetrics = true;
    this.researchService.getExperimentMetrics(this.experimentId).subscribe({
      next: m => { this.metrics = m ?? []; this.loadingMetrics = false; },
      error: () => { this.loadingMetrics = false; },
    });
  }

  loadMatrix(): void {
    this.loadingMatrix = true;
    this.researchService.getConfusionMatrix(this.experimentId).subscribe({
      next: m => { this.matrix = m; this.loadingMatrix = false; },
      error: () => { this.loadingMatrix = false; },
    });
  }

  // ── Metrics helpers ────────────────────────────────────────────────────────

  metricSplits(): string[] {
    return [...new Set(this.metrics.map(m => m.split))];
  }

  metricsForSplit(split: string): any[] {
    return this.metrics.filter(m => m.split === split);
  }

  // ── Confusion matrix helpers ───────────────────────────────────────────────

  matrixMax(): number {
    if (!this.matrix?.matrix) return 1;
    return Math.max(...this.matrix.matrix.flat());
  }

  cellOpacity(val: number): number {
    const max = this.matrixMax();
    return max > 0 ? val / max : 0;
  }

  isDiagonal(i: number, j: number): boolean { return i === j; }

  matrixRowTotal(rowIdx: number): number {
    if (!this.matrix?.matrix?.[rowIdx]) return 0;
    return (this.matrix.matrix[rowIdx] as number[]).reduce((s, v) => s + v, 0);
  }

  totalSamples(): number {
    if (!this.matrix?.matrix) return 0;
    return (this.matrix.matrix as number[][]).flat().reduce((s, v) => s + v, 0);
  }

  overallAccuracy(): string {
    if (!this.matrix?.matrix) return '—';
    let correct = 0, total = 0;
    (this.matrix.matrix as number[][]).forEach((row, i) =>
      row.forEach((val, j) => { total += val; if (i === j) correct += val; })
    );
    return total > 0 ? ((correct / total) * 100).toFixed(1) : '0.0';
  }

  // ── Compare ────────────────────────────────────────────────────────────────

  compare(): void {
    const rawIds = this.compareInput.split(',').map(s => s.trim()).filter(Boolean);
    const ids = [this.experimentId, ...rawIds.map(Number).filter(n => !isNaN(n) && n !== this.experimentId)];
    if (ids.length < 2) { this.compareError = 'Enter at least one other experiment ID.'; return; }
    this.comparing = true;
    this.compareError = '';
    this.researchService.compareExperiments(ids).subscribe({
      next: res => { this.compareResult = res; this.comparing = false; },
      error: () => { this.compareError = 'Compare failed.'; this.comparing = false; },
    });
  }

  compareIds(): string[] {
    return this.compareResult ? Object.keys(this.compareResult) : [];
  }

  allMetricNames(): string[] {
    if (!this.compareResult) return [];
    const names = new Set<string>();
    Object.values(this.compareResult).forEach(arr =>
      arr.filter(m => m.split === 'TEST').forEach(m => names.add(m.metricName))
    );
    return [...names];
  }

  getMetric(expId: string, metricName: string): number | null {
    const row = this.compareResult?.[expId]?.find(m => m.split === 'TEST' && m.metricName === metricName);
    return row?.metricValue ?? null;
  }

  // ── Status helpers ─────────────────────────────────────────────────────────

  get isCreated():   boolean { return this.experiment?.status === 'CREATED'; }
  get isRunning():   boolean { return this.experiment?.status === 'RUNNING'; }
  get isCompleted(): boolean { return this.experiment?.status === 'COMPLETED'; }
  get isFailed():    boolean { return this.experiment?.status === 'FAILED'; }

  statusClass(s: string): string {
    switch (s) {
      case 'COMPLETED': return 'status--completed';
      case 'RUNNING':   return 'status--running';
      case 'FAILED':    return 'status--failed';
      default:          return 'status--created';
    }
  }
}
