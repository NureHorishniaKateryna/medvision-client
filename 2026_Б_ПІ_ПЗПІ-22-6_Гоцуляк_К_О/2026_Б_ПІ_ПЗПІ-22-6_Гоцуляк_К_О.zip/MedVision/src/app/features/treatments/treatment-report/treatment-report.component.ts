import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TreatmentService } from '@core/services/treatment.service';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-treatment-report',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './treatment-report.component.html',
  styleUrl: './treatment-report.component.scss',
})
export class TreatmentReportComponent implements OnInit {
  hospitalId!: number;
  treatmentId!: number;
  report: any = null;
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private treatmentService: TreatmentService,
  ) {}

  ngOnInit(): void {
    this.hospitalId  = +this.route.snapshot.paramMap.get('hospitalId')!;
    this.treatmentId = +this.route.snapshot.paramMap.get('treatmentId')!;
    this.treatmentService.getTreatmentReport(this.hospitalId, this.treatmentId).subscribe({
      next: data => { this.report = data; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  date(val: string | undefined): string { return val?.split('T')[0] ?? '—'; }

  patientName(r: any): string { return r?.treatment?.patientName ?? '—'; }
  doctorName(r: any):  string { return r?.treatment?.primaryDoctorName ?? '—'; }
  status(r: any):      string { return r?.treatment?.status ?? ''; }
  openedAt(r: any):    string { return this.date(r?.treatment?.openedAt); }
  closedAt(r: any):    string { return this.date(r?.treatment?.closedAt); }
  isActive(r: any):   boolean { return ['ACTIVE','OPEN'].includes((r?.treatment?.status ?? '').toUpperCase()); }
}
