import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog } from '@angular/material/dialog';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TreatmentService } from '@core/services/treatment.service';
import { HospitalService } from '@core/services/hospital.service';
import { AuthService } from '@core/services/auth.service';
import { TreatmentCreateDialogComponent } from '../treatment-create-dialog/treatment-create-dialog.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-treatment-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './treatment-list.component.html',
  styleUrl: './treatment-list.component.scss',
})
export class TreatmentListComponent implements OnInit {
  hospitalId!: number;
  hospitalName = '';
  treatments: any[] = [];
  filterStatus = '';
  readonly OPEN_STATUS = 'OPEN';
  loading = true;
  private userRole = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private treatmentService: TreatmentService,
    private hospitalService: HospitalService,
    private authService: AuthService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.hospitalId = +this.route.snapshot.paramMap.get('hospitalId')!;
    const active = this.hospitalService.getActiveHospital();
    this.hospitalName = active?.hospitalName ?? active?.name ?? `Hospital #${this.hospitalId}`;
    const user = this.authService.getUser();
    this.userRole = (user?.userRole || user?.role || '').toUpperCase();
    this.load();
  }

  get canCreate(): boolean { return this.userRole === 'DOCTOR' || this.userRole === 'ADMIN'; }
  get isPatient(): boolean { return this.userRole === 'PATIENT'; }

  load(): void {
    this.loading = true;
    const filters = this.filterStatus ? { status: this.filterStatus } : undefined;
    this.treatmentService.getTreatments(this.hospitalId, filters).subscribe({
      next: data => { this.treatments = data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  setFilter(status: string): void {
    this.filterStatus = status;
    this.load();
  }

  isOpenStatus(t: any): boolean {
    return t.status === 'ACTIVE' || t.status === 'OPEN';
  }

  get activeCount()  { return this.treatments.filter(t => this.isOpenStatus(t)).length; }
  get closedCount()  { return this.treatments.filter(t => t.status === 'CLOSED').length; }

  treatmentId(t: any): number { return t.treatmentId ?? t.id; }

  patientName(t: any): string {
    return t.patientName ?? t.patient?.userName ?? (t.patientId ? `Patient #${t.patientId}` : '—');
  }

  doctorName(t: any): string {
    return t.doctorName ?? t.primaryDoctorName ?? t.doctor?.userName ?? '—';
  }

  createdDate(t: any): string {
    return (t.createdAt ?? t.openedAt ?? t.creationDatetime)?.split('T')[0] ?? '—';
  }

  treatmentTitle(t: any): string {
    return t.title ?? '';
  }

  openCreate(): void {
    const ref = this.dialog.open(TreatmentCreateDialogComponent, {
      data: { hospitalId: this.hospitalId },
      panelClass: 'no-padding-dialog',
    });
    ref.afterClosed().subscribe(data => {
      if (data) this.treatmentService.createTreatment(this.hospitalId, data).subscribe(() => this.load());
    });
  }

  openTreatment(t: any): void {
    if (this.isPatient) return;
    this.router.navigate(['/hospitals', this.hospitalId, 'treatments', this.treatmentId(t)]);
  }
}
