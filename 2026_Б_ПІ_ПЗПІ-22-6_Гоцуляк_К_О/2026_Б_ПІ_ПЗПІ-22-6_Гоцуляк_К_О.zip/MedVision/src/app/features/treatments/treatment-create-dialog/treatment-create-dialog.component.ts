import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TranslateModule } from '@ngx-translate/core';
import { HospitalService } from '@core/services/hospital.service';

@Component({
  selector: 'app-treatment-create-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, TranslateModule],
  templateUrl: './treatment-create-dialog.component.html',
  styleUrl: './treatment-create-dialog.component.scss',
})
export class TreatmentCreateDialogComponent implements OnInit {
  patients: any[] = [];
  filteredPatients: any[] = [];
  loadingPatients = true;

  selectedPatient: any = null;
  searchQuery = '';
  showDropdown = false;

  title = '';
  description = '';

  titleFocused = false;
  descFocused = false;

  constructor(
    private dialogRef: MatDialogRef<TreatmentCreateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private data: { hospitalId: number },
    private hospitalService: HospitalService,
  ) {}

  ngOnInit(): void {
    this.hospitalService.getMemberships(this.data.hospitalId, 'PATIENT').subscribe({
      next: members => {
        this.patients = members ?? [];
        this.filteredPatients = [...this.patients];
        this.loadingPatients = false;
      },
      error: () => { this.loadingPatients = false; },
    });
  }

  onSearch(): void {
    const q = this.searchQuery.trim().toLowerCase();
    this.filteredPatients = q
      ? this.patients.filter(p =>
          p.userName?.toLowerCase().includes(q) || p.email?.toLowerCase().includes(q))
      : [...this.patients];
    this.showDropdown = true;
  }

  selectPatient(p: any): void {
    this.selectedPatient = p;
    this.showDropdown = false;
    this.searchQuery = '';
    this.filteredPatients = [...this.patients];
  }

  clearPatient(): void {
    this.selectedPatient = null;
    this.searchQuery = '';
    this.filteredPatients = [...this.patients];
  }

  closeDropdownDelayed(): void {
    setTimeout(() => { this.showDropdown = false; }, 160);
  }

  getInitials(name: string): string {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    return parts.length === 1
      ? parts[0][0].toUpperCase()
      : (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  get isValid(): boolean {
    return !!(this.selectedPatient && this.title.trim());
  }

  confirm(): void {
    if (!this.isValid) return;
    this.dialogRef.close({
      patientId: this.selectedPatient.userId,
      title: this.title.trim(),
      description: this.description.trim() || undefined,
    });
  }

  cancel(): void {
    this.dialogRef.close(null);
  }

  @HostListener('document:keydown.escape')
  onEscape(): void { this.cancel(); }
}
