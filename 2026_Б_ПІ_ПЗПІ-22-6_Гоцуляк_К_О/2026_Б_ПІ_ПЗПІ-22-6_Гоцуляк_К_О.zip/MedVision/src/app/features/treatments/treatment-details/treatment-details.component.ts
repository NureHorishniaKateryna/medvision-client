import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog } from '@angular/material/dialog';
import { interval, Subscription, switchMap, takeWhile } from 'rxjs';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TreatmentService } from '@core/services/treatment.service';
import { AuthService } from '@core/services/auth.service';
import { AnalysisService } from '@core/services/analysis.service';
import { CompareDialogComponent } from '@features/doctor/compare-dialog/compare-dialog.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-treatment-details',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './treatment-details.component.html',
  styleUrl: './treatment-details.component.scss',
})
export class TreatmentDetailsComponent implements OnInit, OnDestroy {
  hospitalId!: number;
  treatmentId!: number;
  treatment: any = null;
  analyses: any[] = [];
  comparisons: any[] = [];
  conclusion: any = null;

  activeTab: 'analyses' | 'comparisons' | 'conclusion' | 'jobs' = 'analyses';

  // Jobs
  jobs: any[] = [];
  loadingJobs = false;
  retryingJobId: number | null = null;

  uploadFile: File | null = null;
  uploading = false;
  uploadJobStatus = '';
  uploadSuccess = false;
  private pollSub?: Subscription;

  conclusionText = '';
  savingConclusion = false;
  conclusionSaved = false;

  selectedIds: number[] = [];
  comparing = false;

  userRole = '';

  openingComparisonId: number | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private treatmentService: TreatmentService,
    private authService: AuthService,
    private analysisService: AnalysisService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.hospitalId  = +this.route.snapshot.paramMap.get('hospitalId')!;
    this.treatmentId = +this.route.snapshot.paramMap.get('treatmentId')!;
    const user = this.authService.getUser();
    this.userRole = (user?.userRole || user?.role || '').toUpperCase();
    this.load();
  }

  // ── Jobs ──────────────────────────────────────────────────────────────────

  loadJobs(): void {
    this.loadingJobs = true;
    this.treatmentService.listAnalysisJobs(this.hospitalId, this.treatmentId).subscribe({
      next: data => { this.jobs = data ?? []; this.loadingJobs = false; },
      error: () => { this.loadingJobs = false; },
    });
  }

  retryJob(jobId: number): void {
    this.retryingJobId = jobId;
    this.treatmentService.retryAnalysisJob(this.hospitalId, jobId).subscribe({
      next: updated => {
        this.retryingJobId = null;
        const idx = this.jobs.findIndex(j => j.jobId === jobId);
        if (idx > -1) this.jobs[idx] = updated;
      },
      error: () => { this.retryingJobId = null; },
    });
  }

  jobStatusClass(s: string): string {
    switch (s) {
      case 'COMPLETED':  return 'jstatus--completed';
      case 'PROCESSING': return 'jstatus--processing';
      case 'PENDING':    return 'jstatus--pending';
      case 'FAILED':     return 'jstatus--failed';
      case 'CANCELLED':  return 'jstatus--cancelled';
      default:           return 'jstatus--pending';
    }
  }

  analysisStatusBg(a: any): string {
    switch ((a.analysisStatus ?? '').toUpperCase()) {
      case 'REVIEWED':          return 'astatus-bg--reviewed';
      case 'REQUIRES_REVISION': return 'astatus-bg--revision';
      case 'PENDING':           return 'astatus-bg--pending';
      default:                  return 'astatus-bg--pending';
    }
  }

  analysisStatusIcon(a: any): string {
    switch ((a.analysisStatus ?? '').toUpperCase()) {
      case 'REVIEWED':          return 'check_circle';
      case 'REQUIRES_REVISION': return 'warning';
      case 'PENDING':           return 'hourglass_empty';
      default:                  return 'biotech';
    }
  }

  diagnosisShort(a: any): string {
    const d: string = a.analysisDiagnosis ?? '';
    const idx = d.indexOf(' — ');
    return idx > -1 ? d.substring(0, idx) : d;
  }

  ngOnDestroy(): void { this.pollSub?.unsubscribe(); }

  load(): void {
    this.treatmentService.getTreatmentTimeline(this.hospitalId, this.treatmentId).subscribe(data => {
      this.treatment = data.treatment ?? data;
      this.analyses  = data.analyses ?? [];
    });
    this.treatmentService.getComparisons(this.hospitalId, this.treatmentId).subscribe(data => {
      this.comparisons = data;
    });
    this.treatmentService.getConclusion(this.hospitalId, this.treatmentId).subscribe({
      next: data => { this.conclusion = data; this.conclusionText = data?.conclusionText ?? ''; },
      error: () => {},
    });
  }

  get canEdit(): boolean { return this.userRole === 'DOCTOR' || this.userRole === 'ADMIN'; }
  get isActive(): boolean {
    const s = this.treatment?.status;
    return s === 'ACTIVE' || s === 'OPEN';
  }

  patientName(t: any): string {
    return t?.patientName ?? t?.patient?.userName ?? (t?.patientId ? `#${t.patientId}` : '—');
  }
  doctorName(t: any): string {
    return t?.primaryDoctorName ?? t?.doctorName ?? t?.doctor?.userName ?? '—';
  }
  analysisId(a: any): number { return a.analysisId ?? a.imageAnalysisId ?? a.id; }
  comparisonDate(c: any): string { return (c.createdAt ?? c.creationDatetime)?.split('T')[0] ?? '—'; }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.length) { this.uploadFile = input.files[0]; this.uploadJobStatus = ''; }
  }

  uploadAnalysis(): void {
    if (!this.uploadFile) return;
    this.uploading = true;
    this.uploadSuccess = false;
    this.uploadJobStatus = 'Uploading…';

    this.treatmentService.createAnalysis(this.hospitalId, this.treatmentId, this.uploadFile).subscribe({
      next: (res: any) => {
        this.uploadJobStatus = 'Processing…';
        this.startPolling(res.jobId);
      },
      error: () => { this.uploading = false; this.uploadJobStatus = 'Upload failed.'; },
    });
  }

  private startPolling(jobId: string): void {
    this.pollSub = interval(3000).pipe(
      switchMap(() => this.treatmentService.getAnalysisJob(this.hospitalId, jobId)),
      takeWhile((job: any) => !this.isTerminal(job.status), true),
    ).subscribe({
      next: (job: any) => {
        this.uploadJobStatus = `Status: ${job.status}`;
        if (this.isTerminal(job.status)) {
          this.uploading = false;
          this.uploadSuccess = job.status?.toUpperCase() !== 'FAILED' && job.status?.toUpperCase() !== 'ERROR';
          this.uploadFile = null;
          this.load();
        }
      },
      error: () => { this.uploading = false; this.uploadJobStatus = 'Polling failed.'; },
    });
  }

  private isTerminal(status: string): boolean {
    return ['DONE', 'COMPLETED', 'FAILED', 'ERROR'].includes(status?.toUpperCase());
  }

  saveConclusion(): void {
    if (!this.conclusionText.trim()) return;
    this.savingConclusion = true;
    this.treatmentService.setConclusion(this.hospitalId, this.treatmentId, { conclusionText: this.conclusionText }).subscribe({
      next: data => {
        this.conclusion = data;
        this.savingConclusion = false;
        this.conclusionSaved = true;
        setTimeout(() => { this.conclusionSaved = false; }, 3000);
      },
      error: () => { this.savingConclusion = false; },
    });
  }

  toggleSelect(id: number): void {
    const idx = this.selectedIds.indexOf(id);
    if (idx > -1) { this.selectedIds.splice(idx, 1); }
    else {
      if (this.selectedIds.length === 2) this.selectedIds.shift();
      this.selectedIds.push(id);
    }
  }

  isSelected(id: number): boolean { return this.selectedIds.includes(id); }

  compare(): void {
    const [fromId, toId] = this.selectedIds;
    this.comparing = true;
    this.treatmentService.createComparison(this.hospitalId, this.treatmentId, { fromAnalysisId: fromId, toAnalysisId: toId })
      .subscribe({ next: () => { this.comparing = false; this.selectedIds = []; this.load(); }, error: () => { this.comparing = false; } });
  }

  openComparison(c: any): void {
    const fromId = c.fromAnalysisId ?? c.fromId;
    const toId   = c.toAnalysisId   ?? c.toId;
    if (!fromId || !toId) return;
    this.openingComparisonId = c.comparisonId ?? fromId;
    this.analysisService.getComparison(fromId, toId).subscribe({
      next: data => {
        this.openingComparisonId = null;
        this.dialog.open(CompareDialogComponent, {
          data, width: '700px', maxHeight: '90vh', panelClass: 'compare-dialog',
        });
      },
      error: () => { this.openingComparisonId = null; },
    });
  }

  openAnalysis(a: any): void {
    const analysisId = this.analysisId(a);
    const patientId  = a.patientId ?? this.treatment?.patientId;
    if (patientId && analysisId) {
      this.router.navigate(['/doctor/patients', patientId, 'analyses', analysisId]);
    }
  }

  closeTreatment(): void {
    if (!confirm('Close this treatment? This action cannot be undone.')) return;
    this.treatmentService.closeTreatment(this.hospitalId, this.treatmentId).subscribe(() => this.load());
  }

  openReport(): void {
    this.router.navigate(['/hospitals', this.hospitalId, 'treatments', this.treatmentId, 'report']);
  }
}
