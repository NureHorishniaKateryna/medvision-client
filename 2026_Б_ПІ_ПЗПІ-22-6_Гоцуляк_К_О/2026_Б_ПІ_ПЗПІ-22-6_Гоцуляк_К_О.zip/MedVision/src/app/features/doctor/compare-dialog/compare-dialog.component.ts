import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AnalysisService } from '@core/services/analysis.service';
import {MatButton} from '@angular/material/button'; // путь адаптируй
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-compare-dialog',
  templateUrl: './compare-dialog.component.html',
  styleUrls: ['./compare-dialog.component.scss'],
  standalone: true,
  imports: [
    MatButton, TranslateModule],
})
export class CompareDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<CompareDialogComponent>,
    private analysisService: AnalysisService
  ) {}

  downloadPdf() {
    this.analysisService.downloadComparisonPdf(this.data.fromId, this.data.toId).subscribe(blob => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `comparison_${this.data.fromId}_vs_${this.data.toId}.pdf`;
      a.click();
      URL.revokeObjectURL(a.href);
    });
  }
}
