import { Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DoctorService } from '@core/services/doctor.service';
import { AuthService } from '@core/services/auth.service';
import { HospitalService } from '@core/services/hospital.service';
import { TreatmentService } from '@core/services/treatment.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { AnalysisService } from '@core/services/analysis.service';
import { environment } from '@env/environment';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-analysis-page',
  standalone: true,
  templateUrl: './analysis-page.component.html',
  styleUrl: './analysis-page.component.scss',
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, MatTooltipModule, PageHeaderComponent, TranslateModule],
})
export class AnalysisPageComponent implements OnInit, OnDestroy {
  analysisId!: string;
  isNew = false;

  file: File | null = null;
  imagePreview: string | null = null;
  heatmapPreview: string | null = null;
  uploading = false;

  result: string | null = null;
  analysis: any = null;
  analysisStatus = '';

  diagnosis = '';
  analysisDetails = '';
  treatmentRecommendations = '';
  reason = '';
  savingDiagnosis = false;
  diagnosisSaved = false;

  note = '';
  savingNote = false;
  noteSaved = false;

  diagnosisHistory: any[] = [];
  notes: any[] = [];
  imgNotes: any[] = [];

  doctorId!: number;
  patientId!: number;

  activeTab: 'diagnosis' | 'notes' | 'heatmap' | 'review' = 'diagnosis';

  // Image annotation
  @ViewChild('imageRef', { static: false }) imageRef!: ElementRef<HTMLImageElement>;
  drawing = false;
  drawingFinished = false;
  noteText = '';
  rect = { x: 0, y: 0, width: 0, height: 0 };
  private startX = 0;
  private startY = 0;
  savingAreaNote = false;

  loading = true;
  loadFailed = false;

  // ── Review / Explanation ───────────────────────────────────────────────────
  hospitalId: number | null = null;
  treatmentId: number | null = null;
  hasReviewContext = false;

  review: any = null;
  explanation: any = null;
  loadingReview = false;
  loadingExplanation = false;

  reviewDecision: 'CONFIRMED' | 'CORRECTED' | 'REJECTED' | '' = '';
  reviewCorrectedClass: number | null = null;
  reviewComment = '';
  savingReview = false;
  reviewSaved = false;

  private imageObjectUrl: string | null = null;
  private heatmapObjectUrl: string | null = null;

  constructor(
    private route: ActivatedRoute,
    readonly router: Router,
    private doctorService: DoctorService,
    private authService: AuthService,
    private analysisService: AnalysisService,
    private treatmentService: TreatmentService,
    private hospitalService: HospitalService,
    private http: HttpClient,
  ) {}

  @HostListener('window:mousemove', ['$event'])
  onGlobalMouseMove(e: MouseEvent) { this.draw(e); }

  @HostListener('window:mouseup')
  onGlobalMouseUp() { this.finishDrawing(); }

  ngOnInit(): void {
    this.analysisId = this.route.snapshot.paramMap.get('analysesId')!;
    this.patientId  = +this.route.snapshot.paramMap.get('id')!;
    this.isNew      = this.analysisId === 'new';

    const user = this.authService.getUser();
    this.doctorId = user?.userId || user?.id;

    if (this.isNew) { this.loading = false; return; }

    this.doctorService.getAnalysisById(+this.analysisId).subscribe({
      next: data => {
        this.analysis   = data;
        this.result     = data.analysisDiagnosis;
        this.diagnosis  = data.analysisDiagnosis      || '';
        this.analysisDetails           = data.analysisDetails           || '';
        this.treatmentRecommendations  = data.treatmentRecommendations  || '';
        if (data.imageFile?.id) this.fetchImage(data.imageFile.id, 'image');
        this.hospitalId  = data.hospitalId ?? this.hospitalService.getActiveHospital()?.id ?? null;
        this.treatmentId = data.treatmentId ?? null;
        this.hasReviewContext = !!(this.hospitalId && this.treatmentId);
        if (this.hasReviewContext) {
          this.loadReview();
          this.loadExplanation();
        }
        this.loading = false;
      },
      error: () => { this.loading = false; this.loadFailed = true; },
    });

    // getAnalysisStatus may return either a plain string or { status: '...' }
    this.analysisService.getAnalysisStatus(+this.analysisId).subscribe({
      next: s => { this.analysisStatus = s?.status ?? s; },
      error: () => {},
    });
    this.analysisService.getDiagnosisHistory(+this.analysisId).subscribe({
      next: h => { this.diagnosisHistory = h ?? []; },
      error: () => {},
    });
    this.analysisService.getNotesByAnalysisId(+this.analysisId).subscribe({
      next: n => { this.notes = n ?? []; },
      error: () => {},
    });
    this.analysisService.getAnalysisImageNotes(+this.analysisId).subscribe({
      next: n => { this.imgNotes = n ?? []; },
      error: () => {},
    });
  }

  // ── Upload ─────────────────────────────────────────────────────────────────

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;
    this.file = input.files[0];
    const reader = new FileReader();
    reader.onload = () => { this.imagePreview = reader.result as string; };
    reader.readAsDataURL(this.file);
  }

  save(): void {
    if (!this.file || !this.doctorId || !this.patientId) return;
    this.uploading = true;
    this.doctorService.analyzeImage(this.patientId, this.doctorId, this.file).subscribe({
      next: (res: string) => {
        const match = /ID:\s*(\d+)/.exec(res);
        const newId = match ? +match[1] : null;
        if (newId) {
          window.location.href = `/doctor/patients/${this.patientId}/analyses/${newId}`;
        } else {
          this.uploading = false;
        }
      },
      error: () => { this.uploading = false; },
    });
  }

  // ── Status ─────────────────────────────────────────────────────────────────

  updateStatus(newStatus: string): void {
    this.analysisService.updateAnalysisStatus(+this.analysisId, newStatus)
      .subscribe(() => { this.analysisStatus = newStatus; });
  }

  statusLabel(s: string): string {
    switch (s) {
      case 'PENDING':           return 'DOCTOR.ANALYSIS.PENDING';
      case 'REVIEWED':          return 'DOCTOR.ANALYSIS.REVIEWED';
      case 'REQUIRES_REVISION': return 'DOCTOR.ANALYSIS.NEEDS_REVISION';
      default:                  return s;
    }
  }

  statusColor(s: string): string {
    switch (s) {
      case 'PENDING':           return 'pending';
      case 'REVIEWED':          return 'reviewed';
      case 'REQUIRES_REVISION': return 'revision';
      default:                  return 'pending';
    }
  }

  // ── Diagnosis ──────────────────────────────────────────────────────────────

  saveDiagnosis(): void {
    if (!this.diagnosis.trim() || !this.reason.trim()) return;
    this.savingDiagnosis = true;
    this.analysisService.addDiagnosis(
      +this.analysisId, this.doctorId,
      this.diagnosis, this.reason,
      this.analysisDetails, this.treatmentRecommendations,
    ).subscribe({
      next: () => {
        this.savingDiagnosis = false;
        this.diagnosisSaved  = true;
        this.reason = '';
        setTimeout(() => { this.diagnosisSaved = false; }, 3000);
        this.analysisService.getDiagnosisHistory(+this.analysisId).subscribe(h => { this.diagnosisHistory = h; });
      },
      error: () => { this.savingDiagnosis = false; },
    });
  }

  // ── Notes ──────────────────────────────────────────────────────────────────

  saveNote(): void {
    if (!this.note.trim()) return;
    this.savingNote = true;
    this.doctorService.addAnalysisNote(+this.analysisId, this.doctorId, {
      noteText: this.note, noteAreaX: 0, noteAreaY: 0, noteAreaWidth: 0, noteAreaHeight: 0,
    }).subscribe({
      next: (saved: any) => {
        this.savingNote = false;
        this.noteSaved  = true;
        const newNote = saved ?? { noteText: this.note, creationDatetime: new Date().toISOString() };
        this.notes = [...this.notes, newNote];
        this.note = '';
        setTimeout(() => { this.noteSaved = false; }, 3000);
      },
      error: () => { this.savingNote = false; },
    });
  }

  // ── Image annotation ───────────────────────────────────────────────────────

  startDrawing(event: MouseEvent): void {
    // Prevent text selection while drawing
    event.preventDefault();
    const r = this.imageRef.nativeElement.getBoundingClientRect();
    this.startX = event.clientX - r.left;
    this.startY = event.clientY - r.top;
    this.rect = { x: this.startX, y: this.startY, width: 0, height: 0 };
    this.drawing = true;
    this.drawingFinished = false;
    this.noteText = '';
  }

  draw(event: MouseEvent): void {
    if (!this.drawing) return;
    const r = this.imageRef.nativeElement.getBoundingClientRect();
    const cx = event.clientX - r.left;
    const cy = event.clientY - r.top;
    this.rect = {
      x: Math.min(cx, this.startX), y: Math.min(cy, this.startY),
      width: Math.abs(cx - this.startX), height: Math.abs(cy - this.startY),
    };
  }

  finishDrawing(): void {
    if (!this.drawing) return;          // ignore mouseup from button clicks etc.
    this.drawing = false;
    if (this.rect.width > 8 && this.rect.height > 8) {
      this.drawingFinished = true;      // only open popup for a real drag
    }
  }

  cancelNote(): void {
    this.drawingFinished = false;
    this.noteText = '';
    this.rect = { x: 0, y: 0, width: 0, height: 0 };
  }

  saveAreaNote(): void {
    if (!this.noteText.trim()) return;
    this.savingAreaNote = true;
    this.doctorService.addAnalysisNote(+this.analysisId, this.doctorId, {
      noteText: this.noteText,
      noteAreaX: this.rect.x, noteAreaY: this.rect.y,
      noteAreaWidth: this.rect.width, noteAreaHeight: this.rect.height,
    }).subscribe({
      next: () => {
        this.savingAreaNote = false;
        this.noteText = '';
        this.drawingFinished = false;
        this.rect = { x: 0, y: 0, width: 0, height: 0 };
        this.analysisService.getAnalysisImageNotes(+this.analysisId).subscribe({
          next: n => { this.imgNotes = n ?? []; },
          error: () => {},
        });
      },
      error: () => { this.savingAreaNote = false; },
    });
  }

  // ── Review ────────────────────────────────────────────────────────────────

  loadReview(): void {
    this.loadingReview = true;
    this.treatmentService.getReview(this.hospitalId!, this.treatmentId!, +this.analysisId).subscribe({
      next: data => {
        this.review = data;
        // Pre-fill form only if an actual review exists
        if (data.reviewId !== null) {
          this.reviewDecision       = data.decision       ?? '';
          this.reviewCorrectedClass = data.correctedClass ?? null;
          this.reviewComment        = data.comment        ?? '';
        }
        this.loadingReview = false;
      },
      error: () => { this.loadingReview = false; },
    });
  }

  loadExplanation(): void {
    this.loadingExplanation = true;
    this.treatmentService.getExplanation(this.hospitalId!, this.treatmentId!, +this.analysisId).subscribe({
      next: data => {
        this.explanation = data;
        this.loadingExplanation = false;
        if (data.heatmapFile?.id) this.fetchImage(data.heatmapFile.id, 'heatmap');
      },
      error: () => { this.loadingExplanation = false; },
    });
  }

  submitReview(): void {
    if (!this.reviewDecision) return;
    this.savingReview = true;
    const body: any = { decision: this.reviewDecision, comment: this.reviewComment };
    if (this.reviewDecision === 'CORRECTED' && this.reviewCorrectedClass != null) {
      body.correctedClass = this.reviewCorrectedClass;
    }
    this.treatmentService.submitReview(this.hospitalId!, this.treatmentId!, +this.analysisId, body).subscribe({
      next: data => {
        this.review = data;
        this.savingReview = false;
        this.reviewSaved  = true;
        setTimeout(() => { this.reviewSaved = false; }, 3000);
      },
      error: () => { this.savingReview = false; },
    });
  }

  classScoreEntries(): { label: string; pct: number }[] {
    if (!this.explanation?.classScores) return [];
    return Object.entries(this.explanation.classScores).map(([label, val]) => ({
      label,
      pct: Math.round((val as number) * 100),
    }));
  }

  decisionLabel(d: string): string {
    switch (d) {
      case 'CONFIRMED': return 'Confirmed';
      case 'CORRECTED': return 'Corrected';
      case 'REJECTED':  return 'Rejected';
      default: return d;
    }
  }

  ngOnDestroy(): void {
    if (this.imageObjectUrl)   URL.revokeObjectURL(this.imageObjectUrl);
    if (this.heatmapObjectUrl) URL.revokeObjectURL(this.heatmapObjectUrl);
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  private fetchImage(id: number, type: 'image' | 'heatmap'): void {
    this.http.get(`${environment.apiUrl}/files/${id}`, { responseType: 'blob' }).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        if (type === 'image') {
          if (this.imageObjectUrl) URL.revokeObjectURL(this.imageObjectUrl);
          this.imageObjectUrl = url;
          this.imagePreview = url;
        } else {
          if (this.heatmapObjectUrl) URL.revokeObjectURL(this.heatmapObjectUrl);
          this.heatmapObjectUrl = url;
          this.heatmapPreview = url;
        }
      },
      error: () => {},
    });
  }

  pct(val: number | null): string {
    if (val == null) return '—';
    return (val * 100).toFixed(1) + '%';
  }
}
