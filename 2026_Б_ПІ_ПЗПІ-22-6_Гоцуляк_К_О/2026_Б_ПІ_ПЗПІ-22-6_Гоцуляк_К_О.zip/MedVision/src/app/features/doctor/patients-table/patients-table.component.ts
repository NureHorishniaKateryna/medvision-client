import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DoctorService } from '@core/services/doctor.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-patients-table',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatIconModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule],
  templateUrl: './patients-table.component.html',
  styleUrl: './patients-table.component.scss',
})
export class PatientsTableComponent implements OnInit {
  patients: any[] = [];
  loading = true;

  search = '';
  showFilters = false;
  filterGender = '';
  filterHeightMin: number | null = null;
  filterHeightMax: number | null = null;
  filterWeightMin: number | null = null;
  filterWeightMax: number | null = null;
  filterBirthDateFrom = '';
  filterBirthDateTo = '';

  constructor(private doctorService: DoctorService, private router: Router) {}

  ngOnInit(): void {
    this.doctorService.getPatients().subscribe({
      next: data => { this.patients = data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get filteredPatients() {
    return this.patients.filter(p => {
      const name = p.name?.toLowerCase() ?? '';
      return (
        (!this.search || name.includes(this.search.toLowerCase())) &&
        (!this.filterGender || p.gender === this.filterGender) &&
        (this.filterHeightMin == null || p.heightCm >= this.filterHeightMin) &&
        (this.filterHeightMax == null || p.heightCm <= this.filterHeightMax) &&
        (this.filterWeightMin == null || p.weightKg >= this.filterWeightMin) &&
        (this.filterWeightMax == null || p.weightKg <= this.filterWeightMax) &&
        (!this.filterBirthDateFrom || p.birthDate >= this.filterBirthDateFrom) &&
        (!this.filterBirthDateTo   || p.birthDate <= this.filterBirthDateTo)
      );
    });
  }

  get activeFilterCount() {
    return [
      this.filterGender, this.filterHeightMin, this.filterHeightMax,
      this.filterWeightMin, this.filterWeightMax,
      this.filterBirthDateFrom, this.filterBirthDateTo,
    ].filter(v => v !== '' && v != null).length;
  }

  get maleCount()   { return this.patients.filter(p => p.gender === 'MALE').length; }
  get femaleCount() { return this.patients.filter(p => p.gender === 'FEMALE').length; }

  clearFilters(): void {
    this.filterGender = '';
    this.filterHeightMin = this.filterHeightMax = null;
    this.filterWeightMin = this.filterWeightMax = null;
    this.filterBirthDateFrom = this.filterBirthDateTo = '';
  }

  openPatient(id: number): void {
    this.router.navigate(['/doctor/patients', id]);
  }

  getInitials(name: string): string {
    if (!name) return '?';
    const p = name.trim().split(/\s+/);
    return p.length === 1 ? p[0][0].toUpperCase() : (p[0][0] + p[p.length - 1][0]).toUpperCase();
  }

  getAge(birthDate: string): number {
    if (!birthDate) return 0;
    return Math.floor((Date.now() - new Date(birthDate).getTime()) / (365.25 * 24 * 3600 * 1000));
  }

  genderLabel(g: string): string {
    return g === 'MALE' ? 'COMMON.MALE' : g === 'FEMALE' ? 'COMMON.FEMALE' : 'COMMON.OTHER';
  }
}
