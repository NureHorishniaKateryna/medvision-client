import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog } from '@angular/material/dialog';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { DoctorService } from '@core/services/doctor.service';
import { AnalysisService } from '@core/services/analysis.service';
import { CompareDialogComponent } from '../compare-dialog/compare-dialog.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-patient-details-page',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './patient-details-page.component.html',
  styleUrl: './patient-details-page.component.scss',
})
export class PatientDetailsPageComponent implements OnInit {
  patientId!: number;
  patient: any = null;
  analyses: any[] = [];
  loadingPatient = true;
  loadingAnalyses = true;
  selectedAnalysisIds: number[] = [];
  comparing = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private doctorService: DoctorService,
    private analysisService: AnalysisService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.patientId = +this.route.snapshot.paramMap.get('id')!;

    this.doctorService.getPatientById(this.patientId).subscribe({
      next: data => {
        this.patient = {
          id:              data.id ?? data.patientId,
          name:            data.name ?? data.user?.userName ?? '—',
          email:           data.email ?? data.user?.email ?? '—',
          birthDate:       data.birthDate       || null,
          gender:          data.gender          || null,
          heightCm:        data.heightCm        || null,
          weightKg:        data.weightKg        || null,
          address:         data.address         || null,
          allergies:       data.allergies       || null,
          chronicDiseases: data.chronicDiseases || null,
        };
        this.loadingPatient = false;
      },
      error: () => { this.loadingPatient = false; },
    });

    this.analysisService.getAnalysesByPatientId(this.patientId).subscribe({
      next: analyses => {
        this.analyses = (analyses || []).map((a: any) => ({
          id:        a.imageAnalysisId,
          date:      a.creationDatetime?.split('T')[0] || null,
          diagnosis: a.analysisDiagnosis || null,
        }));
        this.loadingAnalyses = false;
      },
      error: () => { this.loadingAnalyses = false; },
    });
  }

  get age(): number {
    if (!this.patient?.birthDate) return 0;
    return Math.floor((Date.now() - new Date(this.patient.birthDate).getTime()) / (365.25 * 24 * 3600 * 1000));
  }

  get initials(): string {
    const name: string = this.patient?.name || '';
    if (!name || name === '—') return '?';
    const parts = name.trim().split(/\s+/);
    return parts.length === 1 ? parts[0][0].toUpperCase() : (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  genderLabel(g: string | null): string {
    switch (g) {
      case 'MALE':   return 'COMMON.MALE';
      case 'FEMALE': return 'COMMON.FEMALE';
      case 'OTHER':  return 'COMMON.OTHER';
      default:       return 'COMMON.NO_DATA';
    }
  }

  diagnosisColor(diagnosis: string | null): string {
    if (!diagnosis) return 'pending';
    const d = diagnosis.toLowerCase();
    if (d.includes('normal') || d.includes('healthy') || d.includes('negative')) return 'normal';
    if (d.includes('abnormal') || d.includes('positive') || d.includes('tumor')) return 'abnormal';
    return 'info';
  }

  diagnosisIcon(diagnosis: string | null): string {
    if (!diagnosis) return 'hourglass_empty';
    const d = diagnosis.toLowerCase();
    if (d.includes('normal') || d.includes('healthy') || d.includes('negative')) return 'check_circle';
    if (d.includes('abnormal') || d.includes('positive') || d.includes('tumor')) return 'warning';
    return 'biotech';
  }

  toggleSelect(id: number): void {
    const idx = this.selectedAnalysisIds.indexOf(id);
    if (idx > -1) {
      this.selectedAnalysisIds.splice(idx, 1);
    } else {
      if (this.selectedAnalysisIds.length === 2) this.selectedAnalysisIds.shift();
      this.selectedAnalysisIds.push(id);
    }
  }

  isSelected(id: number): boolean { return this.selectedAnalysisIds.includes(id); }

  compareSelected(): void {
    const [fromId, toId] = this.selectedAnalysisIds;
    this.comparing = true;
    this.analysisService.getComparison(fromId, toId).subscribe({
      next: data => {
        this.comparing = false;
        this.dialog.open(CompareDialogComponent, { data, width: '700px', maxHeight: '90vh', panelClass: 'compare-dialog' });
      },
      error: () => { this.comparing = false; },
    });
  }

  openAnalysis(analysisId: number): void {
    const segment = analysisId === 0 ? 'new' : analysisId;
    this.router.navigate(['/doctor/patients', this.patientId, 'analyses', segment]);
  }
}
