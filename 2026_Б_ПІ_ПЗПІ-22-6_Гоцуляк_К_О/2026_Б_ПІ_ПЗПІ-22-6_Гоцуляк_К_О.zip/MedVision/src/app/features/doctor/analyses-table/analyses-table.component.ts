import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { AnalysisService } from '@core/services/analysis.service';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-analyses-table',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, MatTooltipModule, PageHeaderComponent, TranslateModule],
  templateUrl: './analyses-table.component.html',
  styleUrl: './analyses-table.component.scss',
})
export class AnalysesTableComponent implements OnInit {
  allData: any[] = [];
  searchText = '';
  selectedStatus = '';
  loading = true;

  constructor(private analysisService: AnalysisService, private router: Router) {}

  ngOnInit(): void {
    this.analysisService.getAllAnalyses().subscribe({
      next: data => { this.allData = data ?? []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get filteredData(): any[] {
    return this.allData.filter(a => {
      const name = (a.patient?.user?.userName ?? a.patientName ?? '').toLowerCase();
      const nameMatch   = !this.searchText || name.includes(this.searchText.toLowerCase());
      const statusMatch = !this.selectedStatus || a.analysisStatus === this.selectedStatus;
      return nameMatch && statusMatch;
    });
  }

  get pendingCount():  number { return this.allData.filter(a => a.analysisStatus === 'PENDING').length; }
  get reviewedCount(): number { return this.allData.filter(a => a.analysisStatus === 'REVIEWED').length; }
  get revisionCount(): number { return this.allData.filter(a => a.analysisStatus === 'REQUIRES_REVISION').length; }

  analysisId(a: any):   number { return a.imageAnalysisId ?? a.id; }
  patientName(a: any):  string { return a.patient?.user?.userName ?? a.patientName ?? '—'; }
  analysisDate(a: any): string { return a.creationDatetime?.split('T')[0] ?? ''; }

  diagnosisColor(a: any): string {
    const d = (a.analysisDiagnosis ?? '').toLowerCase();
    if (!d) return 'pending';
    if (d.includes('normal') || d.includes('healthy') || d.includes('negative')) return 'normal';
    if (d.includes('abnormal') || d.includes('tumor') || d.includes('positive')) return 'abnormal';
    return 'info';
  }

  diagnosisIcon(a: any): string {
    switch (this.diagnosisColor(a)) {
      case 'normal':   return 'check_circle';
      case 'abnormal': return 'warning';
      default:         return 'hourglass_empty';
    }
  }

  statusLabel(s: string): string {
    switch (s) {
      case 'PENDING':           return 'DOCTOR.ANALYSES_TABLE.STATUS_PENDING';
      case 'REVIEWED':          return 'DOCTOR.ANALYSES_TABLE.STATUS_REVIEWED';
      case 'REQUIRES_REVISION': return 'DOCTOR.ANALYSES_TABLE.STATUS_REVISION';
      default:                  return s || '—';
    }
  }

  openAnalysis(a: any): void {
    const patientId = a.patientId ?? a.patient?.patientId;
    const id = this.analysisId(a);
    if (patientId) {
      this.router.navigate(['/doctor/patients', patientId, 'analyses', id]);
    }
  }
}
