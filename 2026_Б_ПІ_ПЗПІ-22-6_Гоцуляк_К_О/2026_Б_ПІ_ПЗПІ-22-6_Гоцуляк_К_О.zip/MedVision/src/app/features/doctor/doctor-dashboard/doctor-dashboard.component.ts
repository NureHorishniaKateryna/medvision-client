import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { DoctorService } from '@core/services/doctor.service';
import { AuthService } from '@core/services/auth.service';
import { HospitalService } from '@core/services/hospital.service';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-doctor-dashboard',
  standalone: true,
  imports: [
    CommonModule, RouterLink, FormsModule,
    MatIconModule, MatButtonModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule],
  templateUrl: './doctor-dashboard.component.html',
  styleUrl: './doctor-dashboard.component.scss',
})
export class DoctorDashboardComponent implements OnInit {
  patients: any[] = [];
  doctorName = '';
  loading = true;
  today = new Date();

  // filters
  search = '';
  showFilters = false;
  filterGender = '';
  filterHeightMin: number | null = null;
  filterHeightMax: number | null = null;
  filterWeightMin: number | null = null;
  filterWeightMax: number | null = null;
  filterBirthDateFrom = '';
  filterBirthDateTo = '';

  constructor(
    private router: Router,
    private doctorService: DoctorService,
    private authService: AuthService,
    private hospitalService: HospitalService,
  ) {}

  ngOnInit(): void {
    this.authService.getProfile().subscribe(user => {
      this.doctorName = user?.userName || user?.name || '';
    });
    this.doctorService.getPatients().subscribe({
      next: data => { this.patients = data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get filteredPatients() {
    return this.patients.filter(p => {
      const name = p.name?.toLowerCase() ?? '';
      return (
        (!this.search || name.includes(this.search.toLowerCase())) &&
        (!this.filterGender || p.gender === this.filterGender) &&
        (this.filterHeightMin == null || p.heightCm >= this.filterHeightMin) &&
        (this.filterHeightMax == null || p.heightCm <= this.filterHeightMax) &&
        (this.filterWeightMin == null || p.weightKg >= this.filterWeightMin) &&
        (this.filterWeightMax == null || p.weightKg <= this.filterWeightMax) &&
        (!this.filterBirthDateFrom || p.birthDate >= this.filterBirthDateFrom) &&
        (!this.filterBirthDateTo   || p.birthDate <= this.filterBirthDateTo)
      );
    });
  }

  get maleCount()   { return this.patients.filter(p => p.gender === 'MALE').length; }
  get femaleCount() { return this.patients.filter(p => p.gender === 'FEMALE').length; }

  get activeFilterCount() {
    return [
      this.filterGender, this.filterHeightMin, this.filterHeightMax,
      this.filterWeightMin, this.filterWeightMax,
      this.filterBirthDateFrom, this.filterBirthDateTo,
    ].filter(v => v !== '' && v != null).length;
  }

  clearFilters(): void {
    this.filterGender = '';
    this.filterHeightMin = this.filterHeightMax = null;
    this.filterWeightMin = this.filterWeightMax = null;
    this.filterBirthDateFrom = this.filterBirthDateTo = '';
  }

  openTreatments(): void {
    const h = this.hospitalService.getActiveHospital();
    const id = h?.id ?? h?.hospitalId;
    if (id) {
      this.router.navigate(['/hospitals', id, 'treatments']);
    } else {
      this.router.navigate(['/hospitals']);
    }
  }

  openPatient(id: number): void {
    this.router.navigate(['/doctor/patients', id]);
  }

  getInitials(name: string): string {
    if (!name) return '?';
    const p = name.trim().split(/\s+/);
    return p.length === 1 ? p[0][0].toUpperCase() : (p[0][0] + p[p.length - 1][0]).toUpperCase();
  }

  getAge(birthDate: string): number {
    if (!birthDate) return 0;
    return Math.floor((Date.now() - new Date(birthDate).getTime()) / (365.25 * 24 * 3600 * 1000));
  }

  genderLabel(g: string): string {
    return g === 'MALE' ? 'COMMON.MALE' : g === 'FEMALE' ? 'COMMON.FEMALE' : 'COMMON.OTHER';
  }
}
