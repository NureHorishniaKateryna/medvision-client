import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '@core/services/auth.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TranslateModule } from '@ngx-translate/core';
import { ThemeService } from '@core/services/theme.service';
import { LanguageService, LangOption } from '@core/services/language.service';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatIconModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule],
  templateUrl: './user-profile.component.html',
  styleUrl: './user-profile.component.scss',
})
export class UserProfileComponent implements OnInit {
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);
  readonly themeService = inject(ThemeService);
  readonly langService = inject(LanguageService);

  form: FormGroup;
  role = '';
  saving = false;
  saveSuccess = false;

  constructor() {
    this.form = this.fb.group({
      name:               [''],
      email:              [''],
      role:               [{ value: '', disabled: true }],
      // Doctor
      position:           [''],
      medicalInstitution: [''],
      department:         [''],
      licenseNumber:      [''],
      achievements:       [''],
      education:          [''],
      // Patient
      birthDate:          [''],
      lastExamDate:       [''],
      address:            [''],
      gender:             [''],
      heightCm:           [''],
      weightKg:           [''],
      chronicDiseases:    [''],
      allergies:          [''],
    });
  }

  ngOnInit(): void {
    this.authService.getProfile().subscribe(profile => {
      this.role = (profile.userRole || profile.role || '').toUpperCase();

      this.form.patchValue({
        name:               profile.name               || '',
        email:              profile.email              || '',
        role:               this.mapRole(this.role),
        position:           profile.position           || '',
        medicalInstitution: profile.medicalInstitution || '',
        department:         profile.department         || '',
        licenseNumber:      profile.licenseNumber      || '',
        achievements:       profile.achievements       || '',
        education:          profile.education          || '',
        birthDate:          profile.birthDate          || '',
        lastExamDate:       profile.lastExamDate       || '',
        address:            profile.address            || '',
        gender:             profile.gender             || '',
        heightCm:           profile.heightCm           || '',
        weightKg:           profile.weightKg           || '',
        chronicDiseases:    profile.chronicDiseases    || '',
        allergies:          profile.allergies          || '',
      });

      if (this.role === 'ADMIN') {
        this.form.get('name')?.disable();
        this.form.get('email')?.disable();
      }

      this.form.markAsPristine();
    });
  }

  save(): void {
    this.saving = true;
    this.saveSuccess = false;
    const raw = this.form.getRawValue();

    const onSuccess = () => {
      this.saving = false;
      this.saveSuccess = true;
      this.form.markAsPristine();
      setTimeout(() => { this.saveSuccess = false; }, 3000);
    };
    const onError = () => { this.saving = false; };

    if (this.role === 'DOCTOR') {
      this.authService.editDoctor({
        name: raw.name, email: raw.email,
        position: raw.position, department: raw.department,
        medicalInstitution: raw.medicalInstitution, licenseNumber: raw.licenseNumber,
        achievements: raw.achievements, education: raw.education,
      }).subscribe({ next: onSuccess, error: onError });
    } else if (this.role === 'PATIENT') {
      this.authService.editPatient({
        name: raw.name, email: raw.email,
        birthDate: raw.birthDate, lastExamDate: raw.lastExamDate,
        gender: raw.gender, address: raw.address,
        heightCm: raw.heightCm, weightKg: raw.weightKg,
        chronicDiseases: raw.chronicDiseases, allergies: raw.allergies,
      }).subscribe({ next: onSuccess, error: onError });
    }
  }

  get initials(): string {
    const name: string = this.form.getRawValue().name || '';
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    return parts.length === 1
      ? parts[0][0].toUpperCase()
      : (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  get displayName(): string { return this.form.getRawValue().name || '—'; }
  get displayEmail(): string { return this.form.getRawValue().email || '—'; }
  get roleLabel(): string    { return this.mapRole(this.role); }

  setLang(event: Event): void {
    this.langService.set((event.target as HTMLSelectElement).value as any);
  }

  get dashboardLink(): string {
    switch (this.role) {
      case 'DOCTOR':  return '/dashboard/doctor';
      case 'PATIENT': return '/dashboard/patient';
      case 'ADMIN':   return '/dashboard/admin';
      default:        return '/dashboard';
    }
  }

  private mapRole(role: string): string {
    switch (role?.toUpperCase()) {
      case 'DOCTOR':  return 'Doctor';
      case 'PATIENT': return 'Patient';
      case 'ADMIN':   return 'Admin';
      default:        return 'User';
    }
  }
}
