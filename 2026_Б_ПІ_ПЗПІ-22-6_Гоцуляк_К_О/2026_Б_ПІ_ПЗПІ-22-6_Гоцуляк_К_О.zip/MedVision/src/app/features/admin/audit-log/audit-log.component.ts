import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TranslateModule } from '@ngx-translate/core';
import { UserService } from '@core/services/user.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';

@Component({
  selector: 'app-audit-log',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatProgressSpinnerModule, TranslateModule, PageHeaderComponent],
  templateUrl: './audit-log.component.html',
  styleUrl: './audit-log.component.scss',
})
export class AuditLogComponent implements OnInit {
  private userService = inject(UserService);

  events: any[] = [];
  loading = true;
  page = 0;
  size = 20;
  totalPages = 0;
  totalElements = 0;
  isFirst = true;
  isLast = true;

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.userService.getAuditEvents(this.page, this.size).subscribe({
      next: (res) => {
        this.events = res.content ?? [];
        this.totalPages = res.totalPages ?? 0;
        this.totalElements = res.totalElements ?? 0;
        this.isFirst = res.first ?? true;
        this.isLast = res.last ?? true;
        this.loading = false;
      },
      error: () => { this.loading = false; },
    });
  }

  prevPage(): void {
    if (!this.isFirst) { this.page--; this.load(); }
  }

  nextPage(): void {
    if (!this.isLast) { this.page++; this.load(); }
  }

  get successCount() { return this.events.filter(e => e.outcome === 'SUCCESS').length; }
  get failureCount() { return this.events.filter(e => e.outcome === 'FAILURE').length; }
  get deniedCount()  { return this.events.filter(e => e.outcome === 'DENIED').length; }

  outcomeClass(outcome: string): string {
    switch (outcome) {
      case 'SUCCESS': return 'outcome--success';
      case 'FAILURE': return 'outcome--failure';
      case 'DENIED':  return 'outcome--denied';
      default:        return 'outcome--other';
    }
  }
}
