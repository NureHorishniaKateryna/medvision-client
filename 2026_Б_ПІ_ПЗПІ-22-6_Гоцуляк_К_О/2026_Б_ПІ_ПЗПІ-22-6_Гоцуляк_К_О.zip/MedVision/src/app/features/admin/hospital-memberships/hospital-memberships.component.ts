import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog } from '@angular/material/dialog';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { HospitalService } from '@core/services/hospital.service';
import { AddMembershipDialogComponent } from '@shared/dialogs/add-membership-dialog/add-membership-dialog.component';
import { InviteDoctorDialogComponent } from '../invite-doctor-dialog/invite-doctor-dialog.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-hospital-memberships',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule,
  ],
  templateUrl: './hospital-memberships.component.html',
  styleUrl: './hospital-memberships.component.scss',
})
export class HospitalMembershipsComponent implements OnInit {
  hospitalId!: number;
  memberships: any[] = [];
  filterRole = '';
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private hospitalService: HospitalService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.hospitalId = +this.route.snapshot.paramMap.get('hospitalId')!;
    this.load();
  }

  load(): void {
    this.loading = true;
    this.hospitalService.getMemberships(this.hospitalId, this.filterRole || undefined).subscribe({
      next: data => { this.memberships = data ?? []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  setFilter(role: string): void {
    this.filterRole = role;
    this.load();
  }

  get totalCount():   number { return this.memberships.length; }
  get activeCount():  number { return this.memberships.filter(m => m.status === 'ACTIVE').length; }
  get doctorCount():  number { return this.memberships.filter(m => m.hospitalRole === 'DOCTOR').length; }
  get patientCount(): number { return this.memberships.filter(m => m.hospitalRole === 'PATIENT').length; }

  getInitials(name: string): string {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  avatarClass(role: string): string {
    const r = (role || '').toLowerCase();
    if (r === 'doctor')         return 'member-avatar--doctor';
    if (r === 'patient')        return 'member-avatar--patient';
    if (r === 'hospital_admin') return 'member-avatar--admin';
    return 'member-avatar--default';
  }

  roleBadgeClass(role: string): string {
    const r = (role || '').toLowerCase();
    if (r === 'doctor')         return 'role-badge--doctor';
    if (r === 'patient')        return 'role-badge--patient';
    if (r === 'hospital_admin') return 'role-badge--admin';
    return 'role-badge--default';
  }

  roleLabel(role: string): string {
    switch ((role || '').toUpperCase()) {
      case 'DOCTOR':         return 'Doctor';
      case 'PATIENT':        return 'Patient';
      case 'HOSPITAL_ADMIN': return 'Hospital Admin';
      default:               return role ?? '—';
    }
  }

  roleIcon(role: string): string {
    switch ((role || '').toUpperCase()) {
      case 'DOCTOR':         return 'medical_services';
      case 'PATIENT':        return 'personal_injury';
      case 'HOSPITAL_ADMIN': return 'admin_panel_settings';
      default:               return 'person';
    }
  }

  openAddDialog(): void {
    const ref = this.dialog.open(AddMembershipDialogComponent, { width: '360px' });
    ref.afterClosed().subscribe(result => {
      if (result) this.hospitalService.addMembership(this.hospitalId, result).subscribe(() => this.load());
    });
  }

  openInviteDialog(): void {
    const ref = this.dialog.open(InviteDoctorDialogComponent, { data: this.hospitalId, width: '520px' });
    ref.afterClosed().subscribe(() => this.load());
  }

  updateStatus(m: any, status: string): void {
    this.hospitalService.updateMembershipStatus(this.hospitalId, m.membershipId ?? m.id, status)
      .subscribe(() => this.load());
  }
}
