import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TranslateModule } from '@ngx-translate/core';
import { SvmService } from '@core/services/svm.service';
import { ResearchService } from '@core/services/research.service';

@Component({
  selector: 'app-svm-models',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatProgressSpinnerModule, MatTooltipModule, PageHeaderComponent, TranslateModule],
  templateUrl: './svm-models.component.html',
  styleUrl: './svm-models.component.scss',
})
export class SvmModelsComponent implements OnInit {
  private svmService = inject(SvmService);
  private researchService = inject(ResearchService);
  private router = inject(Router);

  models: any[] = [];
  activeFullImage: any = null;
  activePatchBased: any = null;
  loadingModels = true;
  loadingActive = true;

  expandedId: number | null = null;
  metrics: any[] = [];
  loadingMetrics = false;
  splitFilter = '';

  actionLoading: Record<number, string> = {};
  confirmArchiveId: number | null = null;

  // Register from experiment
  completedExperiments: any[] = [];
  loadingExperiments = true;
  selectedExpId: number | null = null;
  registerName = '';
  registerVersion = '';
  registering = false;
  registerMsg = '';
  registerError = false;

  ngOnInit(): void {
    this.load();
    this.researchService.getExperiments({ status: 'COMPLETED' }).subscribe({
      next: data => { this.completedExperiments = data ?? []; this.loadingExperiments = false; },
      error: () => { this.loadingExperiments = false; },
    });
  }

  load(): void {
    this.loadingModels = true;
    this.svmService.getModels().subscribe({
      next: data => { this.models = data ?? []; this.loadingModels = false; },
      error: () => { this.loadingModels = false; },
    });

    this.loadingActive = true;
    this.svmService.getActiveModel('FULL_IMAGE').subscribe({
      next: d => { this.activeFullImage = d; this.checkActiveDone(); },
      error: () => { this.activeFullImage = null; this.checkActiveDone(); },
    });
    this.svmService.getActiveModel('PATCH_BASED').subscribe({
      next: d => { this.activePatchBased = d; this.checkActiveDone(); },
      error: () => { this.activePatchBased = null; this.checkActiveDone(); },
    });
  }

  private activeDoneCount = 0;
  private checkActiveDone(): void {
    this.activeDoneCount++;
    if (this.activeDoneCount >= 2) { this.loadingActive = false; this.activeDoneCount = 0; }
  }

  toggleExpand(m: any): void {
    const id = this.modelId(m);
    if (this.expandedId === id) { this.expandedId = null; return; }
    this.expandedId = id;
    this.metrics = [];
    this.fetchMetrics(id);
  }

  fetchMetrics(id?: number): void {
    const modelId = id ?? this.expandedId;
    if (!modelId) return;
    this.loadingMetrics = true;
    const split = (this.splitFilter as any) || undefined;
    this.svmService.getModelMetrics(modelId, split).subscribe({
      next: data => { this.metrics = data ?? []; this.loadingMetrics = false; },
      error: () => { this.loadingMetrics = false; },
    });
  }

  activate(m: any): void {
    const id = this.modelId(m);
    this.actionLoading[id] = 'activate';
    this.svmService.activateModel(id).subscribe({
      next: () => { delete this.actionLoading[id]; this.load(); },
      error: () => { delete this.actionLoading[id]; },
    });
  }

  archiveClick(m: any): void {
    if (this.confirmArchiveId === this.modelId(m)) {
      this.confirmArchive(m);
    } else {
      this.confirmArchiveId = this.modelId(m);
    }
  }

  private confirmArchive(m: any): void {
    const id = this.modelId(m);
    this.confirmArchiveId = null;
    this.actionLoading[id] = 'archive';
    this.svmService.archiveModel(id).subscribe({
      next: () => { delete this.actionLoading[id]; this.load(); },
      error: () => { delete this.actionLoading[id]; },
    });
  }

  cancelArchive(): void { this.confirmArchiveId = null; }

  get registerValid(): boolean {
    return !!(this.selectedExpId && this.registerName.trim() && this.registerVersion.trim());
  }

  registerModel(): void {
    if (!this.registerValid) return;
    this.registering = true;
    this.registerMsg = '';
    this.registerError = false;
    const body: any = {
      experimentId: this.selectedExpId,
      name: this.registerName.trim(),
      version: this.registerVersion.trim(),
    };
    this.svmService.registerModel(body).subscribe({
      next: () => {
        this.registering = false;
        this.registerMsg = 'ADMIN.SVM.REGISTER_SUCCESS';
        this.registerError = false;
        this.selectedExpId = null;
        this.registerName = '';
        this.registerVersion = '';
        this.researchService.getExperiments({ status: 'COMPLETED' }).subscribe({
          next: data => { this.completedExperiments = data ?? []; },
          error: () => {},
        });
        this.load();
      },
      error: () => {
        this.registering = false;
        this.registerMsg = 'ADMIN.SVM.REGISTER_ERROR';
        this.registerError = true;
      },
    });
  }

  canActivate(m: any): boolean {
    return !['ACTIVE', 'ARCHIVED', 'TRAINING', 'FAILED'].includes(m.status);
  }

  canArchive(m: any): boolean {
    return m.status !== 'ARCHIVED' && m.status !== 'ACTIVE';
  }

  statusClass(s: string): string {
    switch (s) {
      case 'ACTIVE':    return 'status--active';
      case 'CANDIDATE': return 'status--candidate';
      case 'TRAINING':  return 'status--training';
      case 'VALIDATED': return 'status--validated';
      case 'ARCHIVED':  return 'status--archived';
      case 'FAILED':    return 'status--failed';
      default:          return 'status--candidate';
    }
  }

  modelId(m: any): number { return m.modelVersionId ?? m.id; }
}
