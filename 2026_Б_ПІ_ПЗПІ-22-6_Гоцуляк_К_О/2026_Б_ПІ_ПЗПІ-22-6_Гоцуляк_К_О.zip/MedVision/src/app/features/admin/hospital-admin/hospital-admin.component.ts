import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router } from '@angular/router';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TranslateModule } from '@ngx-translate/core';
import { HospitalService } from '@core/services/hospital.service';

@Component({
  selector: 'app-hospital-admin',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatIconModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule,
  ],
  templateUrl: './hospital-admin.component.html',
  styleUrl: './hospital-admin.component.scss',
})
export class HospitalAdminComponent implements OnInit {
  hospitals: any[] = [];
  showForm = false;
  editTarget: any = null;
  formName = '';
  formAddress = '';
  saving = false;

  constructor(
    private hospitalService: HospitalService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.hospitalService.getAdminHospitals().subscribe(data => this.hospitals = data);
  }

  openCreate(): void {
    this.editTarget = null;
    this.formName = '';
    this.formAddress = '';
    this.showForm = true;
  }

  openEdit(h: any): void {
    this.editTarget = h;
    this.formName = h.hospitalName ?? h.name ?? '';
    this.formAddress = h.address ?? '';
    this.showForm = true;
  }

  save(): void {
    if (!this.formName.trim()) return;
    this.saving = true;
    const payload = { name: this.formName.trim(), address: this.formAddress.trim() };

    const req$ = this.editTarget
      ? this.hospitalService.updateHospital(this.editTarget.hospitalId ?? this.editTarget.id, payload)
      : this.hospitalService.createHospital(payload);

    req$.subscribe({
      next: () => { this.saving = false; this.showForm = false; this.load(); },
      error: () => { this.saving = false; },
    });
  }

  cancel(): void {
    this.showForm = false;
  }

  openMemberships(h: any): void {
    this.router.navigate(['/hospitals', h.hospitalId ?? h.id, 'memberships']);
  }
}
