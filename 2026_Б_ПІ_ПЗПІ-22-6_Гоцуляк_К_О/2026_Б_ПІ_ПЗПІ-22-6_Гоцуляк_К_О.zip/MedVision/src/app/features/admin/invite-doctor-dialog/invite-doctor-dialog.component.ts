import { Component, Inject, inject } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { InvitationService } from '@core/services/invitation.service';

@Component({
  selector: 'app-invite-doctor-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule, MatProgressSpinnerModule, MatDialogModule, TranslateModule],
  templateUrl: './invite-doctor-dialog.component.html',
  styleUrl: './invite-doctor-dialog.component.scss',
})
export class InviteDoctorDialogComponent {
  private fb = inject(FormBuilder);
  private invitationService = inject(InvitationService);
  private dialogRef = inject(MatDialogRef<InviteDoctorDialogComponent>);

  form: FormGroup;
  loading = false;
  error: string | null = null;
  result: { expiresAt: string } | null = null;

  constructor(@Inject(MAT_DIALOG_DATA) public hospitalId: number) {
    this.form = this.fb.group({
      email:        ['', [Validators.required, Validators.email]],
      name:         ['', Validators.required],
      hospitalRole: ['DOCTOR', Validators.required],
      position:     [''],
      department:   [''],
      licenseNumber:[''],
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = null;

    const payload = {
      hospitalId: this.hospitalId,
      ...this.form.value,
    };

    this.invitationService.inviteDoctor(payload).subscribe({
      next: (res) => {
        this.loading = false;
        this.result = { expiresAt: res.expiresAt };
      },
      error: () => {
        this.loading = false;
        this.error = 'ADMIN.INVITE_DOCTOR.ERROR';
      },
    });
  }

  close(): void {
    this.dialogRef.close(!!this.result);
  }
}
