import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { UserService } from '@core/services/user.service';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-user-dialog',
  standalone: true,
  templateUrl: './user-dialog.component.html',
  styleUrl: './user-dialog.component.scss',
  imports: [CommonModule, FormsModule, MatDialogModule, MatIconModule, MatProgressSpinnerModule, TranslateModule],
})
export class UserDialogComponent {
  roles = ['ADMIN', 'DOCTOR', 'PATIENT'];
  selectedRole: string;

  // Block / unblock
  showBlockForm = false;
  blockReason = '';
  statusLoading = false;
  statusError: string | null = null;

  // Role update
  roleLoading = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public user: any,
    private dialogRef: MatDialogRef<UserDialogComponent>,
    private userService: UserService,
  ) {
    this.selectedRole = user.userRole ?? user.role ?? '';
  }

  get accountStatus(): string {
    return this.user.accountStatus ?? this.user.status ?? 'ACTIVE';
  }

  get isLocked(): boolean {
    return this.accountStatus === 'LOCKED' || this.accountStatus === 'DISABLED';
  }

  updateRole(): void {
    this.roleLoading = true;
    this.userService.updateUserRole(this.user.userId, this.selectedRole).subscribe({
      next: () => { this.roleLoading = false; this.dialogRef.close({ refresh: true }); },
      error: () => { this.roleLoading = false; },
    });
  }

  confirmBlock(): void {
    if (!this.blockReason.trim()) return;
    this.statusLoading = true;
    this.statusError = null;
    this.userService.updateAccountStatus(this.user.userId, 'LOCKED', this.blockReason).subscribe({
      next: () => {
        this.statusLoading = false;
        this.user = { ...this.user, accountStatus: 'LOCKED' };
        this.showBlockForm = false;
        this.blockReason = '';
        this.dialogRef.close({ refresh: true });
      },
      error: () => { this.statusLoading = false; this.statusError = 'ADMIN.USER_DIALOG.STATUS_ERROR'; },
    });
  }

  unblock(): void {
    this.statusLoading = true;
    this.statusError = null;
    this.userService.updateAccountStatus(this.user.userId, 'ACTIVE', 'Unblocked by admin').subscribe({
      next: () => {
        this.statusLoading = false;
        this.user = { ...this.user, accountStatus: 'ACTIVE' };
        this.dialogRef.close({ refresh: true });
      },
      error: () => { this.statusLoading = false; this.statusError = 'ADMIN.USER_DIALOG.STATUS_ERROR'; },
    });
  }

  deleteUser(): void {
    this.userService.deleteUser(this.user.userId).subscribe(() => {
      this.dialogRef.close({ refresh: true });
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
