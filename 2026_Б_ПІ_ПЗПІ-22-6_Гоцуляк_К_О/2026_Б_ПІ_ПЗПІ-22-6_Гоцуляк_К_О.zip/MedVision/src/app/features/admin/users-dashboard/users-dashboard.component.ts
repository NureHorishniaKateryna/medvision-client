import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserService } from '@core/services/user.service';
import { AuthService } from '@core/services/auth.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TranslateModule } from '@ngx-translate/core';
import { UserDialogComponent } from '../user-dialog/user-dialog.component';

@Component({
  selector: 'app-users-dashboard',
  standalone: true,
  templateUrl: './users-dashboard.component.html',
  styleUrl: './users-dashboard.component.scss',
  imports: [
    CommonModule, FormsModule, RouterLink,
    MatIconModule, MatButtonModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule,
  ],
})
export class UsersDashboardComponent implements OnInit {
  private userService = inject(UserService);
  private authService = inject(AuthService);
  private dialog = inject(MatDialog);

  users: any[] = [];
  loading = true;
  today = new Date();
  adminName = '';
  search = '';

  ngOnInit(): void {
    const user = this.authService.getUser();
    this.adminName = user?.userName || user?.name || '';
    this.loadUsers();
  }

  loadUsers(): void {
    this.loading = true;
    this.userService.getAllUsers().subscribe({
      next: data => { this.users = data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get filteredUsers() {
    if (!this.search.trim()) return this.users;
    const q = this.search.toLowerCase();
    return this.users.filter(u =>
      u.userName?.toLowerCase().includes(q) ||
      u.email?.toLowerCase().includes(q) ||
      u.userRole?.toLowerCase().includes(q)
    );
  }

  get doctorCount()  { return this.users.filter(u => u.userRole?.toUpperCase() === 'DOCTOR').length; }
  get patientCount() { return this.users.filter(u => u.userRole?.toUpperCase() === 'PATIENT').length; }
  get adminCount()   { return this.users.filter(u => u.userRole?.toUpperCase() === 'ADMIN').length; }

  roleColor(role: string): string {
    switch (role?.toUpperCase()) {
      case 'ADMIN':   return 'admin';
      case 'DOCTOR':  return 'doctor';
      case 'PATIENT': return 'patient';
      default:        return 'other';
    }
  }

  roleIcon(role: string): string {
    switch (role?.toUpperCase()) {
      case 'ADMIN':   return 'shield';
      case 'DOCTOR':  return 'stethoscope';
      case 'PATIENT': return 'personal_injury';
      default:        return 'person';
    }
  }

  getInitials(name: string): string {
    if (!name) return '?';
    const p = name.trim().split(/\s+/);
    return p.length === 1 ? p[0][0].toUpperCase() : (p[0][0] + p[p.length - 1][0]).toUpperCase();
  }

  openUserDialog(user: any): void {
    const ref = this.dialog.open(UserDialogComponent, { data: user, width: '400px' });
    ref.afterClosed().subscribe(result => {
      if (result?.refresh) this.loadUsers();
    });
  }
}
