import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { HospitalService } from '@core/services/hospital.service';
import { AuthService } from '@core/services/auth.service';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-hospital-select',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule, MatProgressSpinnerModule, PageHeaderComponent, TranslateModule],
  templateUrl: './hospital-select.component.html',
  styleUrl: './hospital-select.component.scss',
})
export class HospitalSelectComponent implements OnInit {
  hospitals: any[] = [];
  loading = true;
  error = '';
  userRole = '';
  activeHospitalId: number | null = null;
  selectingId: number | null = null;

  constructor(
    private hospitalService: HospitalService,
    private authService: AuthService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    const user = this.authService.getUser();
    this.userRole = (user?.userRole || user?.role || '').toUpperCase();

    this.hospitalService.activeHospital$.subscribe(h => {
      this.activeHospitalId = h?.id ?? h?.hospitalId ?? null;
    });

    this.hospitalService.getMyHospitals().subscribe({
      next: data => { this.hospitals = data || []; this.loading = false; },
      error: () => { this.error = 'Failed to load hospitals'; this.loading = false; },
    });
  }

  hospitalId(h: any): number {
    return h.hospitalId ?? h.id;
  }

  hospitalName(h: any): string {
    return h.hospitalName ?? h.name ?? 'Unnamed Hospital';
  }

  isActive(h: any): boolean {
    return this.activeHospitalId !== null && this.activeHospitalId === this.hospitalId(h);
  }

  select(h: any): void {
    const id = this.hospitalId(h);
    this.selectingId = id;
    this.hospitalService.selectHospital(id).subscribe({
      next: () => { this.selectingId = null; this.navigateToDashboard(); },
      error: () => { this.selectingId = null; this.navigateToDashboard(); },
    });
  }

  getInitials(name: string): string {
    if (!name) return '?';
    const words = name.trim().split(/\s+/);
    return words.length === 1
      ? words[0].slice(0, 2).toUpperCase()
      : (words[0][0] + words[1][0]).toUpperCase();
  }

  private navigateToDashboard(): void {
    switch (this.userRole) {
      case 'DOCTOR':  this.router.navigate(['/dashboard/doctor']);  break;
      case 'PATIENT': this.router.navigate(['/dashboard/patient']); break;
      default:        this.router.navigate(['/dashboard/admin']);   break;
    }
  }
}
