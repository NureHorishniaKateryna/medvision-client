import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgApexchartsModule } from 'ng-apexcharts';
import { ApexAxisChartSeries, ApexChart, ApexXAxis, ApexPlotOptions, ApexDataLabels, ApexTooltip, ApexYAxis } from 'ng-apexcharts';
import { PatientService } from '@core/services/patient.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { environment } from '@env/environment';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-result-details-page',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatProgressSpinnerModule, NgApexchartsModule, PageHeaderComponent, TranslateModule],
  templateUrl: './result-details-page.component.html',
  styleUrl: './result-details-page.component.scss',
})
export class ResultDetailsPageComponent implements OnInit, OnDestroy {
  private route          = inject(ActivatedRoute);
  private patientService = inject(PatientService);
  private http           = inject(HttpClient);

  analysisId!: number;
  analysis: any = null;
  loading = true;
  loadFailed = false;

  imagePreview: string | null = null;
  heatmapPreview: string | null = null;
  private imageObjectUrl: string | null = null;
  private heatmapObjectUrl: string | null = null;

  activeTab: 'overview' | 'scan' | 'heatmap' = 'overview';

  chartSeries: ApexAxisChartSeries = [];
  chartOptions: ApexChart = {
    type: 'bar', height: 220, toolbar: { show: false },
    fontFamily: 'inherit', foreColor: '#475569',
  };
  chartPlotOptions: ApexPlotOptions = {
    bar: { borderRadius: 6, columnWidth: '40%', distributed: true },
  };
  chartDataLabels: ApexDataLabels = { enabled: false };
  chartTooltip: ApexTooltip = {
    y: { formatter: (val: number) => (val * 100).toFixed(1) + '%' },
  };
  chartColors = ['#6366f1', '#10b981', '#3b82f6'];
  xAxis: ApexXAxis = {
    categories: ['Accuracy', 'Recall', 'Precision'],
    labels: { style: { fontFamily: 'inherit', fontWeight: '600', fontSize: '12px' } },
    axisBorder: { show: false }, axisTicks: { show: false },
  };
  yAxis: ApexYAxis = {
    min: 0, max: 1,
    labels: { formatter: (val: number) => (val * 100).toFixed(0) + '%' },
  };

  ngOnInit(): void {
    this.analysisId = +this.route.snapshot.paramMap.get('id')!;
    this.patientService.getAnalysisById(this.analysisId).subscribe({
      next: data => {
        this.analysis = data;
        this.chartSeries = [{
          name: 'Score',
          data: [data.analysisAccuracy ?? 0, data.analysisRecall ?? 0, data.analysisPrecision ?? 0],
        }];
        if (data.imageFile?.id)   this.fetchImage(data.imageFile.id,   'image');
        if (data.heatmapFile?.id) this.fetchImage(data.heatmapFile.id, 'heatmap');
        this.loading = false;
      },
      error: () => { this.loading = false; this.loadFailed = true; },
    });
  }

  ngOnDestroy(): void {
    if (this.imageObjectUrl)   URL.revokeObjectURL(this.imageObjectUrl);
    if (this.heatmapObjectUrl) URL.revokeObjectURL(this.heatmapObjectUrl);
  }

  private fetchImage(id: number, type: 'image' | 'heatmap'): void {
    this.http.get(`${environment.apiUrl}/files/${id}`, { responseType: 'blob' }).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        if (type === 'image') {
          if (this.imageObjectUrl) URL.revokeObjectURL(this.imageObjectUrl);
          this.imageObjectUrl = url;
          this.imagePreview = url;
        } else {
          if (this.heatmapObjectUrl) URL.revokeObjectURL(this.heatmapObjectUrl);
          this.heatmapObjectUrl = url;
          this.heatmapPreview = url;
        }
      },
      error: () => {},
    });
  }

  pct(val: number | null | undefined): string {
    if (val == null) return '—';
    return (val * 100).toFixed(1) + '%';
  }

  diagnosisColor(d: string | null): string {
    if (!d) return 'pending';
    const lower = d.toLowerCase();
    if (lower.includes('normal') || lower.includes('healthy') || lower.includes('negative')) return 'normal';
    if (lower.includes('abnormal') || lower.includes('tumor') || lower.includes('positive')) return 'abnormal';
    return 'info';
  }

  diagnosisIcon(d: string | null): string {
    switch (this.diagnosisColor(d)) {
      case 'normal':   return 'check_circle';
      case 'abnormal': return 'warning';
      default:         return 'hourglass_empty';
    }
  }

  downloadPdf(): void {
    this.patientService.getAnalysisPdf(this.analysisId).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `analysis-${this.analysisId}.pdf`;
      link.click();
      window.URL.revokeObjectURL(url);
    });
  }
}
