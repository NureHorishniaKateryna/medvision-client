import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RouterModule } from '@angular/router';
import { PatientService } from '@core/services/patient.service';
import { AuthService } from '@core/services/auth.service';
import { PageHeaderComponent } from '@shared/components/page-header/page-header.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  imports: [
    CommonModule, RouterModule,
    MatIconModule, MatButtonModule, MatProgressSpinnerModule,
    PageHeaderComponent, TranslateModule],
  templateUrl: './patient-dashboard.component.html',
  styleUrl: './patient-dashboard.component.scss',
})
export class PatientDashboardComponent implements OnInit {
  private patientService = inject(PatientService);
  private authService = inject(AuthService);

  analyses: any[] = [];
  loading = true;
  today = new Date();
  patientName = '';

  ngOnInit(): void {
    const user = this.authService.getUser();
    this.patientName = user?.userName || user?.name || '';

    this.patientService.getAllAnalyses().subscribe({
      next: data => {
        this.analyses = (data || []).map((item: any) => ({
          id: item.imageAnalysisId,
          date: item.creationDatetime?.split('T')[0] || null,
          diagnosis: item.analysisDiagnosis || null,
          fileName: item.imageFile?.imageFileName || null,
        }));
        this.loading = false;
      },
      error: () => { this.loading = false; },
    });
  }

  get totalCount()    { return this.analyses.length; }
  get diagnosedCount(){ return this.analyses.filter(a => !!a.diagnosis).length; }
  get pendingCount()  { return this.analyses.filter(a => !a.diagnosis).length; }

  statusIcon(diagnosis: string | null): string {
    if (!diagnosis) return 'hourglass_empty';
    const d = diagnosis.toLowerCase();
    if (d.includes('normal') || d.includes('healthy') || d.includes('negative')) return 'check_circle';
    if (d.includes('abnormal') || d.includes('positive') || d.includes('tumor')) return 'warning';
    return 'biotech';
  }

  statusColor(diagnosis: string | null): string {
    if (!diagnosis) return 'pending';
    const d = diagnosis.toLowerCase();
    if (d.includes('normal') || d.includes('healthy') || d.includes('negative')) return 'normal';
    if (d.includes('abnormal') || d.includes('positive') || d.includes('tumor')) return 'abnormal';
    return 'info';
  }

  statusLabel(diagnosis: string | null): string {
    return diagnosis || 'Pending';
  }
}
