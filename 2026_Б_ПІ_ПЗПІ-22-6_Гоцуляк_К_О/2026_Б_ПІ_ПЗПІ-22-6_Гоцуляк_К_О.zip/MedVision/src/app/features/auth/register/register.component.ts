import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '@core/services/auth.service';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, MatIconModule, MatProgressSpinnerModule, TranslateModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss',
})
export class RegisterComponent {
  form: FormGroup;
  loading = false;
  showPassword = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
  ) {
    this.form = this.fb.group({
      name:               ['', Validators.required],
      email:              ['', [Validators.required, Validators.email]],
      password:           ['', Validators.required],
      role:               ['patient', Validators.required],
      // Patient
      birthDate:          [''],
      gender:             [''],
      // Doctor
      position:           [''],
      medicalInstitution: [''],
      department:         [''],
      licenseNumber:      [''],
    });
  }

  get role() { return this.form.get('role')?.value; }

  selectRole(r: string): void { this.form.get('role')?.setValue(r); }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.loading = true;

    const v = this.form.value;
    const role = this.role;
    let request: any;

    if (role === 'patient') {
      request = { name: v.name, email: v.email, password: v.password, birthDate: v.birthDate, gender: v.gender };
      this.authService.registerPatient(request).subscribe(this.handleSuccess());
    } else if (role === 'doctor') {
      request = { name: v.name, email: v.email, password: v.password, position: v.position, medicalInstitution: v.medicalInstitution, department: v.department, licenseNumber: v.licenseNumber };
      this.authService.registerDoctor(request).subscribe(this.handleSuccess());
    } else {
      request = { name: v.name, email: v.email, password: v.password };
      this.authService.registerAdmin(request).subscribe(this.handleSuccess());
    }
  }

  private handleSuccess() {
    return () => {
      this.loading = false;
      switch (this.role) {
        case 'patient': this.router.navigate(['/dashboard/patient']); break;
        case 'doctor':  this.router.navigate(['/dashboard/doctor']);  break;
        default:        this.router.navigate(['/login']);
      }
    };
  }
}
