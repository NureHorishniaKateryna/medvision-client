import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '@core/services/auth.service';
import { NavService } from '@core/services/nav.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, MatIconModule, MatProgressSpinnerModule, TranslateModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  form: FormGroup;
  loading = false;
  error: string | null = null;
  showPassword = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private navService: NavService,
    private translate: TranslateService,
  ) {
    this.form = this.fb.group({
      email:    ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = null;

    this.authService.login(this.form.value).subscribe({
      next: (profile) => {
        this.loading = false;
        this.navService.open();
        const role = (profile.role || profile.userRole || '').toUpperCase();
        switch (role) {
          case 'PATIENT': this.router.navigate(['/dashboard/patient']); break;
          case 'DOCTOR':  this.router.navigate(['/dashboard/doctor']);  break;
          case 'ADMIN':   this.router.navigate(['/dashboard/admin']);   break;
          default:        this.router.navigate(['/login']);
        }
      },
      error: () => {
        this.loading = false;
        this.error = this.translate.instant('AUTH.LOGIN.ERROR');
      },
    });
  }
}
