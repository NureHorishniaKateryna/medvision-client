import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet, NavigationEnd, RouterLink, RouterLinkActive } from '@angular/router';
import { MatSidenavModule, MatSidenav } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { filter } from 'rxjs';
import { NavService } from '@core/services/nav.service';
import { AuthService } from '@core/services/auth.service';
import { HospitalService } from '@core/services/hospital.service';
import { LanguageService } from '@core/services/language.service';
import { ThemeService } from '@core/services/theme.service';
import { TranslateModule } from '@ngx-translate/core';

interface NavItem {
  label: string;
  icon: string;
  route: string;
  roles: string[];
}

interface NavSection {
  title: string;
  items: NavItem[];
  roles: string[];  // which roles see this whole section
}

const NAV_SECTIONS: NavSection[] = [
  {
    title: 'NAV.SECTION_MAIN',
    roles: [],
    items: [
      { label: 'NAV.DASHBOARD', icon: 'dashboard', route: '/dashboard/patient', roles: ['PATIENT'] },
      { label: 'NAV.DASHBOARD', icon: 'dashboard', route: '/dashboard/doctor',  roles: ['DOCTOR']  },
      { label: 'NAV.USERS',     icon: 'group',     route: '/dashboard/admin',   roles: ['ADMIN']   },
    ]
  },
  {
    title: 'NAV.SECTION_CLINICAL',
    roles: ['DOCTOR'],
    items: [
      { label: 'NAV.PATIENTS',     icon: 'people',  route: '/doctor/patients', roles: ['DOCTOR'] },
      { label: 'NAV.ALL_ANALYSES', icon: 'biotech', route: '/doctor/analyses', roles: ['DOCTOR'] },
    ]
  },
  {
    title: 'NAV.SECTION_HOSPITALS',
    roles: [],
    items: [
      { label: 'NAV.MY_HOSPITALS', icon: 'business', route: '/hospitals', roles: [] },
    ]
  },
  {
    title: 'NAV.SECTION_ADMIN',
    roles: ['ADMIN'],
    items: [
      { label: 'NAV.HOSPITAL_MGMT', icon: 'local_hospital', route: '/admin/hospitals',  roles: ['ADMIN'] },
      { label: 'NAV.SVM_MODELS',    icon: 'model_training', route: '/admin/svm-models', roles: ['ADMIN'] },
      { label: 'NAV.AUDIT_LOG',     icon: 'policy',         route: '/admin/audit-log',  roles: ['ADMIN'] },
    ]
  },
  {
    title: 'NAV.SECTION_RESEARCH',
    roles: ['ADMIN'],
    items: [
      { label: 'NAV.DATASETS',    icon: 'dataset',  route: '/research/datasets',    roles: ['ADMIN'] },
      { label: 'NAV.EXPERIMENTS', icon: 'science',  route: '/research/experiments', roles: ['ADMIN'] },
    ]
  },
  {
    title: 'NAV.SECTION_ACCOUNT',
    roles: [],
    items: [
      { label: 'NAV.PROFILE', icon: 'manage_accounts', route: '/profile', roles: [] },
    ]
  },
];

const PUBLIC_ROUTES = ['/login', '/register', '/forgot-password', '/reset-password', '/accept-invite'];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule, RouterOutlet, RouterLink, RouterLinkActive,
    MatSidenavModule, MatListModule, MatIconModule,
    MatButtonModule, MatDividerModule, MatTooltipModule,
    TranslateModule,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  @ViewChild('sidenav') sidenav!: MatSidenav;

  readonly navService = inject(NavService);
  private authService = inject(AuthService);
  private hospitalService = inject(HospitalService);
  private router = inject(Router);
  private languageService = inject(LanguageService);
  private themeService = inject(ThemeService);

  showNav = false;
  navSections: NavSection[] = [];
  activeHospitalName = '';
  userName = '';
  userRoleLabel = '';
  userInitials = '';

  get treatmentsRoute(): any[] | null {
    const h = this.hospitalService.getActiveHospital();
    const id = h?.id ?? h?.hospitalId;
    return id ? ['/hospitals', id, 'treatments'] : null;
  }

  ngOnInit(): void {
    this.languageService.init();
    this.themeService.init();

    this.navService.isOpen$.subscribe(open => {
      setTimeout(() => {
        if (this.sidenav) open ? this.sidenav.open() : this.sidenav.close();
      });
    });

    this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe((e: any) => {
      const url: string = e.urlAfterRedirects ?? e.url;
      const isPublic = PUBLIC_ROUTES.some(r => url.startsWith(r));
      const authed = !!this.authService.getToken();
      this.showNav = !isPublic && authed;
      if (this.showNav) {
        this.loadUserContext();
        if (!this.sidenav?.opened) this.navService.open();
      }
    });
  }

  filterItems(items: NavItem[]): NavItem[] {
    return items.filter(i => i.roles.length === 0 || i.roles.includes(this.userRoleLabel.toUpperCase() === 'ADMIN' ? 'ADMIN' : this.userRoleLabel.toUpperCase()));
  }

  private loadUserContext(): void {
    const user = this.authService.getUser();
    if (!user) return;

    this.userName = user.userName || '';
    const role = (user.userRole || user.role || '').toUpperCase();
    this.userRoleLabel = this.mapRole(role);
    this.userInitials = this.getInitials(this.userName);

    this.navSections = NAV_SECTIONS
      .filter(s => s.roles.length === 0 || s.roles.includes(role))
      .map(s => ({
        ...s,
        items: s.items.filter(i => i.roles.length === 0 || i.roles.includes(role))
      }))
      .filter(s => s.items.length > 0);

    this.hospitalService.activeHospital$.subscribe(h => {
      this.activeHospitalName = h?.hospitalName ?? h?.name ?? '';
    });
  }

  private mapRole(role: string): string {
    switch (role) {
      case 'DOCTOR':  return 'Doctor';
      case 'PATIENT': return 'Patient';
      case 'ADMIN':   return 'Admin';
      default:        return 'User';
    }
  }

  private getInitials(name: string): string {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0][0].toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
}
