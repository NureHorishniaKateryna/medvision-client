export const environment = {
  production: false,
  apiUrl: 'https://api.medvision-nure.org/api'
};
